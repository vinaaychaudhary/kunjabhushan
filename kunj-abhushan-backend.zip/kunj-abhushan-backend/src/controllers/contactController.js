'use strict';

const { query } = require('../config/db');
const { sendSuccess, sendError, paginate, paginationMeta } = require('../utils/responseHelper');

/**
 * POST /api/contact
 * Public endpoint — save contact form message.
 */
async function submitContact(req, res, next) {
  try {
    const { name, email, mobile, subject, message } = req.body;
    if (!name || !email || !message) {
      return sendError(res, 400, 'name, email, and message are required.');
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) return sendError(res, 400, 'Invalid email address.');

    await query(
      'INSERT INTO contact_messages (name, email, mobile, subject, message) VALUES (?, ?, ?, ?, ?)',
      [name.trim(), email.trim(), mobile || null, subject || null, message.trim()]
    );

    return sendSuccess(res, 201, 'Message received. We will get back to you within 24 hours. 🙏');
  } catch (err) { next(err); }
}

// ── Admin ─────────────────────────────────────────────────────

/**
 * GET /api/contact  [admin]
 */
async function getAllMessages(req, res, next) {
  try {
    const { page, limit, offset } = paginate(req.query);
    const { status } = req.query;
    const where  = status ? 'WHERE status = ?' : '';
    const params = status ? [status] : [];

    const [messages] = await query(
      `SELECT * FROM contact_messages ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    const [countRows] = await query(`SELECT COUNT(*) AS total FROM contact_messages ${where}`, params);

    return sendSuccess(res, 200, 'Messages fetched.', messages, paginationMeta(countRows[0].total, page, limit));
  } catch (err) { next(err); }
}

/**
 * PATCH /api/contact/:id/status  [admin]
 */
async function updateMessageStatus(req, res, next) {
  try {
    const { status, admin_notes } = req.body;
    const validStatuses = ['unread', 'read', 'replied', 'closed'];
    if (!validStatuses.includes(status)) return sendError(res, 400, 'Invalid status.');

    await query(
      'UPDATE contact_messages SET status = ?, admin_notes = ? WHERE id = ?',
      [status, admin_notes || null, req.params.id]
    );
    return sendSuccess(res, 200, 'Message status updated.');
  } catch (err) { next(err); }
}

/**
 * DELETE /api/contact/:id  [admin]
 */
async function deleteMessage(req, res, next) {
  try {
    await query('DELETE FROM contact_messages WHERE id = ?', [req.params.id]);
    return sendSuccess(res, 200, 'Message deleted.');
  } catch (err) { next(err); }
}

module.exports = { submitContact, getAllMessages, updateMessageStatus, deleteMessage };
