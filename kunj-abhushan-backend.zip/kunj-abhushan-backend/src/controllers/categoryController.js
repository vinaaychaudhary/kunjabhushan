'use strict';

const categoryModel = require('../models/categoryModel');
const productModel  = require('../models/productModel');
const { sendSuccess, sendError, paginate, paginationMeta } = require('../utils/responseHelper');
const { uniqueSlug } = require('../utils/slugHelper');

/**
 * GET /api/categories
 */
async function getCategories(req, res, next) {
  try {
    const categories = await categoryModel.findAll(true);
    return sendSuccess(res, 200, 'Categories fetched.', categories);
  } catch (err) { next(err); }
}

/**
 * GET /api/categories/:slugOrId
 */
async function getCategory(req, res, next) {
  try {
    const { slugOrId } = req.params;
    const cat = /^\d+$/.test(slugOrId)
      ? await categoryModel.findById(parseInt(slugOrId))
      : await categoryModel.findBySlug(slugOrId);
    if (!cat) return sendError(res, 404, 'Category not found.');
    return sendSuccess(res, 200, 'Category fetched.', cat);
  } catch (err) { next(err); }
}

/**
 * GET /api/categories/:slugOrId/products
 */
async function getCategoryProducts(req, res, next) {
  try {
    const { slugOrId } = req.params;
    const cat = /^\d+$/.test(slugOrId)
      ? await categoryModel.findById(parseInt(slugOrId))
      : await categoryModel.findBySlug(slugOrId);
    if (!cat) return sendError(res, 404, 'Category not found.');

    const { page, limit, offset } = paginate(req.query);
    const where  = 'p.category_id = ?';
    const params = [cat.id];

    const sortMap = {
      price_asc: 'p.price ASC', price_desc: 'p.price DESC',
      rating: 'p.avg_rating DESC', newest: 'p.created_at DESC', popular: 'p.sold_count DESC',
    };
    const orderBy = sortMap[req.query.sort] || 'p.sort_order ASC, p.sold_count DESC';

    const [products, total] = await Promise.all([
      productModel.findAll({ where, params, limit, offset, orderBy }),
      productModel.countAll({ where, params }),
    ]);

    return sendSuccess(res, 200, 'Category products fetched.', { category: cat, products }, paginationMeta(total, page, limit));
  } catch (err) { next(err); }
}

/**
 * POST /api/categories  [admin]
 */
async function createCategory(req, res, next) {
  try {
    const { name, description, icon_emoji, parent_id, sort_order, meta_title, meta_desc } = req.body;
    if (!name) return sendError(res, 400, 'Category name is required.');

    const slug = await uniqueSlug(name, (s) => categoryModel.slugExists(s));
    const image_url = req.file ? `/uploads/categories/${req.file.filename}` : null;

    const cat = await categoryModel.create({ name, slug, description, image_url, icon_emoji, parent_id, sort_order, meta_title, meta_desc });
    return sendSuccess(res, 201, 'Category created.', cat);
  } catch (err) { next(err); }
}

/**
 * PUT /api/categories/:id  [admin]
 */
async function updateCategory(req, res, next) {
  try {
    const { id } = req.params;
    const cat = await categoryModel.findById(parseInt(id));
    if (!cat) return sendError(res, 404, 'Category not found.');

    const data = { ...req.body };
    if (req.file) data.image_url = `/uploads/categories/${req.file.filename}`;

    const updated = await categoryModel.updateById(parseInt(id), data);
    return sendSuccess(res, 200, 'Category updated.', updated);
  } catch (err) { next(err); }
}

/**
 * DELETE /api/categories/:id  [admin]
 */
async function deleteCategory(req, res, next) {
  try {
    const { id } = req.params;
    await categoryModel.updateById(parseInt(id), { is_active: 0 });
    return sendSuccess(res, 200, 'Category deactivated.');
  } catch (err) { next(err); }
}

module.exports = { getCategories, getCategory, getCategoryProducts, createCategory, updateCategory, deleteCategory };
