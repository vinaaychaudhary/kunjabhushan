'use strict';

const { query } = require('../config/db');
const userModel = require('../models/userModel');
const { sendSuccess, sendError, paginate, paginationMeta } = require('../utils/responseHelper');

/**
 * GET /api/admin/dashboard
 * High-level stats for admin panel.
 */
async function getDashboardStats(req, res, next) {
  try {
    const [
      [totalOrders],
      [pendingOrders],
      [totalRevenue],
      [totalUsers],
      [totalProducts],
      [lowStockProducts],
      [unreadMessages],
      recentOrders,
    ] = await Promise.all([
      query('SELECT COUNT(*) AS val FROM orders'),
      query('SELECT COUNT(*) AS val FROM orders WHERE status IN ("pending","confirmed","processing")'),
      query('SELECT IFNULL(SUM(total_amount), 0) AS val FROM orders WHERE payment_status = "paid"'),
      query('SELECT COUNT(*) AS val FROM users WHERE role = "customer"'),
      query('SELECT COUNT(*) AS val FROM products WHERE is_active = 1'),
      query('SELECT COUNT(*) AS val FROM products WHERE stock_qty <= low_stock_alert AND is_active = 1'),
      query('SELECT COUNT(*) AS val FROM contact_messages WHERE status = "unread"'),
      query(`
        SELECT o.id, o.order_number, o.total_amount, o.status, o.payment_status,
               o.created_at, u.name AS user_name
        FROM orders o JOIN users u ON u.id = o.user_id
        ORDER BY o.created_at DESC LIMIT 5
      `),
    ]);

    return sendSuccess(res, 200, 'Dashboard stats fetched.', {
      total_orders:     totalOrders[0].val,
      pending_orders:   pendingOrders[0].val,
      total_revenue:    parseFloat(totalRevenue[0].val).toFixed(2),
      total_users:      totalUsers[0].val,
      total_products:   totalProducts[0].val,
      low_stock_alerts: lowStockProducts[0].val,
      unread_messages:  unreadMessages[0].val,
      recent_orders:    recentOrders[0],
    });
  } catch (err) { next(err); }
}

/**
 * GET /api/admin/users
 */
async function getAllUsers(req, res, next) {
  try {
    const { page, limit, offset } = paginate(req.query);
    const { search, role } = req.query;
    const conditions = ['1 = 1'];
    const params = [];
    if (role)   { conditions.push('role = ?');                         params.push(role); }
    if (search) { conditions.push('(name LIKE ? OR mobile LIKE ? OR email LIKE ?)'); params.push(`%${search}%`, `%${search}%`, `%${search}%`); }

    const where = `WHERE ${conditions.join(' AND ')}`;
    const [users] = await query(
      `SELECT id, name, email, mobile, role, is_verified, is_active, last_login, created_at
       FROM users ${where} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );
    const [countRows] = await query(`SELECT COUNT(*) AS total FROM users ${where}`, params);
    return sendSuccess(res, 200, 'Users fetched.', users, paginationMeta(countRows[0].total, page, limit));
  } catch (err) { next(err); }
}

/**
 * PATCH /api/admin/users/:id
 */
async function updateUser(req, res, next) {
  try {
    const { is_active, role } = req.body;
    const updates = {};
    if (is_active !== undefined) updates.is_active = is_active ? 1 : 0;
    if (role && ['customer','admin'].includes(role)) updates.role = role;
    await userModel.updateById(parseInt(req.params.id), updates);
    return sendSuccess(res, 200, 'User updated.');
  } catch (err) { next(err); }
}

/**
 * GET /api/admin/coupons
 */
async function getCoupons(req, res, next) {
  try {
    const [coupons] = await query('SELECT * FROM coupons ORDER BY created_at DESC');
    return sendSuccess(res, 200, 'Coupons fetched.', coupons);
  } catch (err) { next(err); }
}

/**
 * POST /api/admin/coupons
 */
async function createCoupon(req, res, next) {
  try {
    const { code, description, type, value, min_order_value, max_discount, usage_limit, valid_from, valid_until } = req.body;
    if (!code || !type || value === undefined) return sendError(res, 400, 'code, type, and value are required.');
    if (!['percent','flat'].includes(type)) return sendError(res, 400, 'type must be "percent" or "flat".');

    await query(
      `INSERT INTO coupons (code, description, type, value, min_order_value, max_discount, usage_limit, valid_from, valid_until)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [code.toUpperCase(), description || null, type, value, min_order_value || 0, max_discount || null, usage_limit || null, valid_from || null, valid_until || null]
    );
    return sendSuccess(res, 201, 'Coupon created.');
  } catch (err) { next(err); }
}

/**
 * PATCH /api/admin/coupons/:id
 */
async function updateCoupon(req, res, next) {
  try {
    const allowed = ['description','type','value','min_order_value','max_discount','usage_limit','is_active','valid_from','valid_until'];
    const updates = [];
    const values  = [];
    for (const [k, v] of Object.entries(req.body)) {
      if (allowed.includes(k)) { updates.push(`${k} = ?`); values.push(v); }
    }
    if (!updates.length) return sendError(res, 400, 'No valid fields to update.');
    values.push(req.params.id);
    await query(`UPDATE coupons SET ${updates.join(', ')} WHERE id = ?`, values);
    return sendSuccess(res, 200, 'Coupon updated.');
  } catch (err) { next(err); }
}

/**
 * DELETE /api/admin/coupons/:id
 */
async function deleteCoupon(req, res, next) {
  try {
    await query('DELETE FROM coupons WHERE id = ?', [req.params.id]);
    return sendSuccess(res, 200, 'Coupon deleted.');
  } catch (err) { next(err); }
}

/**
 * GET /api/admin/analytics/revenue
 * Daily revenue for last 30 days.
 */
async function getRevenueAnalytics(req, res, next) {
  try {
    const [rows] = await query(
      `SELECT DATE(created_at) AS date, COUNT(*) AS orders, SUM(total_amount) AS revenue
       FROM orders
       WHERE payment_status = 'paid' AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
       GROUP BY DATE(created_at)
       ORDER BY date ASC`
    );
    return sendSuccess(res, 200, 'Revenue analytics fetched.', rows);
  } catch (err) { next(err); }
}

/**
 * GET /api/admin/analytics/top-products
 */
async function getTopProducts(req, res, next) {
  try {
    const [rows] = await query(
      `SELECT p.id, p.name, p.sku, p.price, p.sold_count, p.avg_rating, p.stock_qty,
              SUM(oi.qty) AS units_sold, SUM(oi.total_price) AS revenue
       FROM products p
       JOIN order_items oi ON oi.product_id = p.id
       JOIN orders o ON o.id = oi.order_id AND o.payment_status = 'paid'
       GROUP BY p.id
       ORDER BY revenue DESC
       LIMIT 10`
    );
    return sendSuccess(res, 200, 'Top products fetched.', rows);
  } catch (err) { next(err); }
}

module.exports = {
  getDashboardStats, getAllUsers, updateUser,
  getCoupons, createCoupon, updateCoupon, deleteCoupon,
  getRevenueAnalytics, getTopProducts,
};
