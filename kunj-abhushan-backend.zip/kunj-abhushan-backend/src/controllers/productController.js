'use strict';

const productModel = require('../models/productModel');
const categoryModel = require('../models/categoryModel');
const { sendSuccess, sendError, paginate, paginationMeta } = require('../utils/responseHelper');
const { slugify, uniqueSlug } = require('../utils/slugHelper');
const { query } = require('../config/db');

/**
 * GET /api/products
 * Query params: page, limit, category, sort, min_price, max_price, featured, bestseller, new_arrival
 */
async function getProducts(req, res, next) {
  try {
    const { page, limit, offset } = paginate(req.query);
    const { category, sort, min_price, max_price, featured, bestseller, new_arrival } = req.query;

    const conditions = [];
    const params = [];

    if (category) {
      const cat = await categoryModel.findBySlug(category);
      if (!cat) return sendError(res, 404, 'Category not found.');
      conditions.push('p.category_id = ?');
      params.push(cat.id);
    }
    if (min_price) { conditions.push('p.price >= ?'); params.push(parseFloat(min_price)); }
    if (max_price) { conditions.push('p.price <= ?'); params.push(parseFloat(max_price)); }
    if (featured === '1')    { conditions.push('p.is_featured = 1'); }
    if (bestseller === '1')  { conditions.push('p.is_bestseller = 1'); }
    if (new_arrival === '1') { conditions.push('p.is_new_arrival = 1'); }

    const sortMap = {
      price_asc:  'p.price ASC',
      price_desc: 'p.price DESC',
      rating:     'p.avg_rating DESC',
      newest:     'p.created_at DESC',
      popular:    'p.sold_count DESC',
    };
    const orderBy = sortMap[sort] || 'p.sort_order ASC, p.sold_count DESC';
    const where  = conditions.join(' AND ');

    const [products, total] = await Promise.all([
      productModel.findAll({ where, params, limit, offset, orderBy }),
      productModel.countAll({ where, params }),
    ]);

    return sendSuccess(res, 200, 'Products fetched.', products, paginationMeta(total, page, limit));
  } catch (err) { next(err); }
}

/**
 * GET /api/products/featured
 */
async function getFeaturedProducts(req, res, next) {
  try {
    const limit = parseInt(req.query.limit) || 8;
    const products = await productModel.findAll({ where: 'p.is_featured = 1', limit, orderBy: 'p.sort_order ASC' });
    return sendSuccess(res, 200, 'Featured products fetched.', products);
  } catch (err) { next(err); }
}

/**
 * GET /api/products/bestsellers
 */
async function getBestsellers(req, res, next) {
  try {
    const limit = parseInt(req.query.limit) || 8;
    const products = await productModel.findAll({ where: 'p.is_bestseller = 1', limit, orderBy: 'p.sold_count DESC' });
    return sendSuccess(res, 200, 'Bestsellers fetched.', products);
  } catch (err) { next(err); }
}

/**
 * GET /api/products/new-arrivals
 */
async function getNewArrivals(req, res, next) {
  try {
    const limit = parseInt(req.query.limit) || 8;
    const products = await productModel.findAll({ where: 'p.is_new_arrival = 1', limit, orderBy: 'p.created_at DESC' });
    return sendSuccess(res, 200, 'New arrivals fetched.', products);
  } catch (err) { next(err); }
}

/**
 * GET /api/products/:slugOrId
 */
async function getProduct(req, res, next) {
  try {
    const { slugOrId } = req.params;
    let product;
    if (/^\d+$/.test(slugOrId)) {
      product = await productModel.findById(parseInt(slugOrId));
    } else {
      product = await productModel.findBySlug(slugOrId);
    }
    if (!product) return sendError(res, 404, 'Product not found.');
    const related = await productModel.findRelated(product.category_id, product.id, 8);
    return sendSuccess(res, 200, 'Product fetched.', { ...product, related });
  } catch (err) { next(err); }
}

/**
 * GET /api/products/:id/related
 */
async function getRelatedProducts(req, res, next) {
  try {
    const product = await productModel.findById(parseInt(req.params.id));
    if (!product) return sendError(res, 404, 'Product not found.');
    const related = await productModel.findRelated(product.category_id, product.id, parseInt(req.query.limit) || 8);
    return sendSuccess(res, 200, 'Related products fetched.', related);
  } catch (err) { next(err); }
}

// ── Admin CRUD ────────────────────────────────────────────────

/**
 * POST /api/products  [admin]
 */
async function createProduct(req, res, next) {
  try {
    const data = req.body;
    if (!data.name || !data.price || !data.category_id) {
      return sendError(res, 400, 'name, price, and category_id are required.');
    }
    data.slug = await uniqueSlug(data.name, async (s) => !!(await productModel.findBySlug(s)));
    const product = await productModel.create(data);

    if (req.file) {
      await productModel.addImage(product.id, `/uploads/products/${req.file.filename}`, data.name, true);
    }
    return sendSuccess(res, 201, 'Product created.', product);
  } catch (err) { next(err); }
}

/**
 * PUT /api/products/:id  [admin]
 */
async function updateProduct(req, res, next) {
  try {
    const { id } = req.params;
    const product = await productModel.findById(parseInt(id));
    if (!product) return sendError(res, 404, 'Product not found.');
    const updated = await productModel.updateById(parseInt(id), req.body);
    return sendSuccess(res, 200, 'Product updated.', updated);
  } catch (err) { next(err); }
}

/**
 * DELETE /api/products/:id  [admin]
 */
async function deleteProduct(req, res, next) {
  try {
    const { id } = req.params;
    await query('UPDATE products SET is_active = 0 WHERE id = ?', [id]);
    return sendSuccess(res, 200, 'Product deactivated.');
  } catch (err) { next(err); }
}

/**
 * POST /api/products/:id/images  [admin]
 */
async function addProductImage(req, res, next) {
  try {
    if (!req.file) return sendError(res, 400, 'No image uploaded.');
    const { id } = req.params;
    const { is_primary, alt_text } = req.body;
    const imageUrl = `/uploads/products/${req.file.filename}`;
    const imageId = await productModel.addImage(parseInt(id), imageUrl, alt_text || null, is_primary === '1');
    return sendSuccess(res, 201, 'Image added.', { id: imageId, image_url: imageUrl });
  } catch (err) { next(err); }
}

/**
 * DELETE /api/products/:id/images/:imageId  [admin]
 */
async function deleteProductImage(req, res, next) {
  try {
    await productModel.deleteImage(parseInt(req.params.imageId), parseInt(req.params.id));
    return sendSuccess(res, 200, 'Image deleted.');
  } catch (err) { next(err); }
}

module.exports = {
  getProducts, getFeaturedProducts, getBestsellers, getNewArrivals,
  getProduct, getRelatedProducts, createProduct, updateProduct,
  deleteProduct, addProductImage, deleteProductImage,
};
