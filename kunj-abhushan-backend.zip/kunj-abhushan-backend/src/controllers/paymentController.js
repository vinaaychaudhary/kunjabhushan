'use strict';

const { createRazorpayOrder, verifyPaymentSignature, verifyWebhookSignature, fetchPayment } = require('../services/razorpayService');
const orderModel = require('../models/orderModel');
const { query } = require('../config/db');
const { sendSuccess, sendError } = require('../utils/responseHelper');

/**
 * POST /api/payment/create-order
 * Create a Razorpay order for an existing pending order.
 * Body: { order_id }
 */
async function createPaymentOrder(req, res, next) {
  try {
    const { order_id } = req.body;
    if (!order_id) return sendError(res, 400, 'order_id is required.');

    const order = await orderModel.findById(parseInt(order_id), req.user.id);
    if (!order) return sendError(res, 404, 'Order not found.');
    if (order.payment_status === 'paid') return sendError(res, 400, 'Order is already paid.');

    const razorpayOrder = await createRazorpayOrder(
      order.total_amount,
      order.order_number,
      { user_id: req.user.id.toString(), order_id: order.id.toString() }
    );

    // Save Razorpay order id to payments table
    await query(
      `INSERT INTO payments (order_id, user_id, razorpay_order_id, amount, currency, status)
       VALUES (?, ?, ?, ?, 'INR', 'created')
       ON DUPLICATE KEY UPDATE razorpay_order_id = VALUES(razorpay_order_id), status = 'created'`,
      [order.id, req.user.id, razorpayOrder.id, order.total_amount]
    );

    return sendSuccess(res, 200, 'Razorpay order created.', {
      razorpay_order_id: razorpayOrder.id,
      razorpay_key:      process.env.RAZORPAY_KEY_ID,
      amount:            razorpayOrder.amount,
      currency:          razorpayOrder.currency,
      order_number:      order.order_number,
      prefill: {
        name:    req.user.name,
        contact: req.user.mobile,
        email:   req.user.email || '',
      },
    });
  } catch (err) { next(err); }
}

/**
 * POST /api/payment/verify
 * Verify payment after Razorpay checkout completes.
 * Body: { razorpay_order_id, razorpay_payment_id, razorpay_signature, order_id }
 */
async function verifyPayment(req, res, next) {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature, order_id } = req.body;

    if (!razorpay_order_id || !razorpay_payment_id || !razorpay_signature || !order_id) {
      return sendError(res, 400, 'razorpay_order_id, razorpay_payment_id, razorpay_signature, and order_id are required.');
    }

    const isValid = verifyPaymentSignature({ razorpay_order_id, razorpay_payment_id, razorpay_signature });
    if (!isValid) {
      await query(
        `UPDATE payments SET status = 'failed' WHERE razorpay_order_id = ?`,
        [razorpay_order_id]
      );
      return sendError(res, 400, 'Payment verification failed. Invalid signature.');
    }

    // Fetch payment details from Razorpay
    let rzpPayment;
    try { rzpPayment = await fetchPayment(razorpay_payment_id); } catch (_) { rzpPayment = {}; }

    // Update payment record
    await query(
      `UPDATE payments
       SET status = 'paid', razorpay_payment_id = ?, razorpay_signature = ?,
           method = ?, bank = ?, captured_at = NOW()
       WHERE razorpay_order_id = ?`,
      [
        razorpay_payment_id,
        razorpay_signature,
        rzpPayment.method || null,
        rzpPayment.bank   || null,
        razorpay_order_id,
      ]
    );

    // Update order status
    await query(
      `UPDATE orders SET payment_status = 'paid', status = 'confirmed' WHERE id = ?`,
      [order_id]
    );

    const order = await orderModel.findById(parseInt(order_id), req.user.id);
    return sendSuccess(res, 200, 'Payment verified successfully. Order confirmed!', { order });
  } catch (err) { next(err); }
}

/**
 * POST /api/payment/webhook
 * Razorpay webhook handler (raw body, no auth middleware).
 */
async function handleWebhook(req, res) {
  try {
    const signature = req.headers['x-razorpay-signature'];
    const isValid   = verifyWebhookSignature(req.body, signature);
    if (!isValid) return res.status(400).json({ success: false, message: 'Invalid webhook signature.' });

    const event   = JSON.parse(req.body.toString());
    const entity  = event.payload?.payment?.entity;
    if (!entity) return res.json({ success: true });

    if (event.event === 'payment.captured') {
      // Update payment and order on server-initiated capture
      await query(
        `UPDATE payments SET status = 'paid', razorpay_payment_id = ?, captured_at = NOW() WHERE razorpay_order_id = ?`,
        [entity.id, entity.order_id]
      );
      const [pRows] = await query('SELECT order_id FROM payments WHERE razorpay_order_id = ?', [entity.order_id]);
      if (pRows.length) {
        await query(`UPDATE orders SET payment_status = 'paid', status = 'confirmed' WHERE id = ?`, [pRows[0].order_id]);
      }
    }

    if (event.event === 'payment.failed') {
      await query(
        `UPDATE payments SET status = 'failed', error_code = ?, error_description = ? WHERE razorpay_order_id = ?`,
        [entity.error_code || null, entity.error_description || null, entity.order_id]
      );
    }

    return res.json({ success: true });
  } catch (err) {
    console.error('Webhook error:', err.message);
    return res.status(500).json({ success: false });
  }
}

/**
 * GET /api/payment/status/:orderId
 */
async function getPaymentStatus(req, res, next) {
  try {
    const order = await orderModel.findById(parseInt(req.params.orderId), req.user.id);
    if (!order) return sendError(res, 404, 'Order not found.');
    return sendSuccess(res, 200, 'Payment status fetched.', {
      order_id:       order.id,
      order_number:   order.order_number,
      payment_status: order.payment_status,
      order_status:   order.status,
      payment:        order.payment,
    });
  } catch (err) { next(err); }
}

module.exports = { createPaymentOrder, verifyPayment, handleWebhook, getPaymentStatus };
