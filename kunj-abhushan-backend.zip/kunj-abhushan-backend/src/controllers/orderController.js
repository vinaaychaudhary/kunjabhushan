'use strict';

const orderModel = require('../models/orderModel');
const cartModel  = require('../models/cartModel');
const productModel = require('../models/productModel');
const couponModel  = require('../models/couponModel');
const { beginTransaction } = require('../config/db');
const { generateOrderNumber } = require('../utils/slugHelper');
const { sendSuccess, sendError, paginate, paginationMeta } = require('../utils/responseHelper');
const { query } = require('../config/db');

/**
 * GET /api/orders
 */
async function getMyOrders(req, res, next) {
  try {
    const { page, limit, offset } = paginate(req.query);
    const [orders, total] = await Promise.all([
      orderModel.getUserOrders(req.user.id, limit, offset),
      orderModel.countUserOrders(req.user.id),
    ]);
    return sendSuccess(res, 200, 'Orders fetched.', orders, paginationMeta(total, page, limit));
  } catch (err) { next(err); }
}

/**
 * GET /api/orders/:id
 */
async function getOrder(req, res, next) {
  try {
    const order = await orderModel.findById(parseInt(req.params.id), req.user.role === 'admin' ? null : req.user.id);
    if (!order) return sendError(res, 404, 'Order not found.');
    return sendSuccess(res, 200, 'Order fetched.', order);
  } catch (err) { next(err); }
}

/**
 * POST /api/orders
 * Creates an order from the user's cart. Returns order + Razorpay key for payment.
 * Body: { address_id, payment_method, coupon_code, notes }
 */
async function createOrder(req, res, next) {
  let conn = null;
  try {
    const { address_id, payment_method = 'razorpay', coupon_code, notes } = req.body;

    // 1. Validate address
    const [addrRows] = await query(
      'SELECT * FROM user_addresses WHERE id = ? AND user_id = ?',
      [address_id, req.user.id]
    );
    if (!addrRows.length) return sendError(res, 400, 'Invalid shipping address.');
    const addr = addrRows[0];

    // 2. Get cart
    const cart = await cartModel.getCartWithItems(req.user.id);
    if (!cart.items.length) return sendError(res, 400, 'Your cart is empty.');

    // 3. Validate stock
    for (const item of cart.items) {
      if (!item.is_active) return sendError(res, 400, `"${item.name}" is no longer available.`);
      if (item.qty > item.stock_qty) return sendError(res, 400, `Only ${item.stock_qty} units of "${item.name}" available.`);
    }

    // 4. Validate coupon if provided
    let discountAmount = 0;
    let validCoupon = null;
    if (coupon_code) {
      const couponCheck = await couponModel.validate(coupon_code, cart.subtotal);
      if (!couponCheck.valid) return sendError(res, 400, couponCheck.message);
      discountAmount = couponCheck.discount;
      validCoupon = couponCheck.coupon;
    }

    const totalAmount = Math.max(0, cart.subtotal - discountAmount + cart.shipping_charge + cart.gst_amount);

    // 5. Start transaction
    conn = await beginTransaction();

    // 6. Decrement stock
    for (const item of cart.items) {
      await conn.execute(
        'UPDATE products SET stock_qty = stock_qty - ?, sold_count = sold_count + ? WHERE id = ? AND stock_qty >= ?',
        [item.qty, item.qty, item.product_id, item.qty]
      );
      const [check] = await conn.execute('SELECT stock_qty FROM products WHERE id = ?', [item.product_id]);
      if (check[0].stock_qty < 0) {
        await conn.rollback();
        return sendError(res, 400, `"${item.name}" went out of stock. Please update your cart.`);
      }
    }

    // 7. Create order record
    const orderNumber = generateOrderNumber();
    const orderId = await orderModel.create(conn, {
      order_number: orderNumber,
      user_id: req.user.id,
      payment_method,
      subtotal: cart.subtotal,
      discount_amount: discountAmount,
      coupon_code: validCoupon ? validCoupon.code : null,
      shipping_charge: cart.shipping_charge,
      gst_amount: cart.gst_amount,
      total_amount: totalAmount,
      ship_name: addr.full_name,
      ship_mobile: addr.mobile,
      ship_line1: addr.line1,
      ship_line2: addr.line2,
      ship_city: addr.city,
      ship_state: addr.state,
      ship_pincode: addr.pincode,
      ship_country: addr.country,
      notes: notes || null,
    }, cart.items.map(i => ({ product_id: i.product_id, name: i.name, sku: i.sku, image_url: i.image_url, qty: i.qty, price: parseFloat(i.price) })));

    // 8. Increment coupon usage
    if (validCoupon) await couponModel.incrementUsage(validCoupon.code);

    // 9. Clear cart
    await cartModel.clearCart(req.user.id);

    await conn.commit();

    const order = await orderModel.findById(orderId, req.user.id);
    return sendSuccess(res, 201, 'Order placed successfully.', {
      order,
      razorpay_key: process.env.RAZORPAY_KEY_ID,
    });
  } catch (err) {
    if (conn) await conn.rollback().catch(() => {});
    next(err);
  } finally {
    if (conn) conn.release();
  }
}

/**
 * POST /api/orders/:id/cancel
 */
async function cancelOrder(req, res, next) {
  try {
    const order = await orderModel.findById(parseInt(req.params.id), req.user.id);
    if (!order) return sendError(res, 404, 'Order not found.');
    if (!['pending', 'confirmed'].includes(order.status)) {
      return sendError(res, 400, `Order cannot be cancelled at "${order.status}" stage.`);
    }

    await query(
      'UPDATE orders SET status = "cancelled", cancelled_reason = ? WHERE id = ?',
      [req.body.reason || 'Cancelled by customer', order.id]
    );

    // Restore stock
    for (const item of order.items) {
      await query(
        'UPDATE products SET stock_qty = stock_qty + ?, sold_count = GREATEST(0, sold_count - ?) WHERE id = ?',
        [item.qty, item.qty, item.product_id]
      );
    }

    return sendSuccess(res, 200, 'Order cancelled successfully.');
  } catch (err) { next(err); }
}

// ── Admin ─────────────────────────────────────────────────────

/**
 * GET /api/orders/admin/all  [admin]
 */
async function getAllOrders(req, res, next) {
  try {
    const { page, limit, offset } = paginate(req.query);
    const { status, payment_status } = req.query;

    const conditions = [];
    const params = [];
    if (status)         { conditions.push('o.status = ?');         params.push(status); }
    if (payment_status) { conditions.push('o.payment_status = ?'); params.push(payment_status); }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

    const [orders] = await query(
      `SELECT o.id, o.order_number, o.status, o.payment_status, o.total_amount,
              o.ship_name, o.ship_city, o.created_at,
              u.name AS user_name, u.mobile AS user_mobile,
              (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) AS item_count
       FROM orders o JOIN users u ON u.id = o.user_id
       ${where} ORDER BY o.created_at DESC LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );

    const [countRows] = await query(`SELECT COUNT(*) AS total FROM orders o ${where}`, params);
    return sendSuccess(res, 200, 'All orders fetched.', orders, paginationMeta(countRows[0].total, page, limit));
  } catch (err) { next(err); }
}

/**
 * PATCH /api/orders/:id/status  [admin]
 */
async function updateOrderStatus(req, res, next) {
  try {
    const { status, tracking_number, courier_name } = req.body;
    const validStatuses = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded'];
    if (!validStatuses.includes(status)) return sendError(res, 400, 'Invalid status.');

    const updates = ['status = ?'];
    const values  = [status];
    if (tracking_number) { updates.push('tracking_number = ?'); values.push(tracking_number); }
    if (courier_name)    { updates.push('courier_name = ?');    values.push(courier_name); }
    values.push(req.params.id);

    await query(`UPDATE orders SET ${updates.join(', ')} WHERE id = ?`, values);
    return sendSuccess(res, 200, 'Order status updated.');
  } catch (err) { next(err); }
}

module.exports = { getMyOrders, getOrder, createOrder, cancelOrder, getAllOrders, updateOrderStatus };
