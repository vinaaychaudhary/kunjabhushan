'use strict';

const reviewModel  = require('../models/reviewModel');
const productModel = require('../models/productModel');
const orderModel   = require('../models/orderModel');
const { sendSuccess, sendError, paginate, paginationMeta } = require('../utils/responseHelper');
const { query } = require('../config/db');

/**
 * GET /api/reviews/product/:productId
 */
async function getProductReviews(req, res, next) {
  try {
    const { productId } = req.params;
    const { page, limit, offset } = paginate(req.query);

    const [reviews, total, distribution] = await Promise.all([
      reviewModel.getProductReviews(parseInt(productId), limit, offset),
      reviewModel.countProductReviews(parseInt(productId)),
      reviewModel.getRatingDistribution(parseInt(productId)),
    ]);

    return sendSuccess(res, 200, 'Reviews fetched.', { reviews, distribution }, paginationMeta(total, page, limit));
  } catch (err) { next(err); }
}

/**
 * POST /api/reviews
 * Body: { product_id, rating, title, body, order_id }
 */
async function createReview(req, res, next) {
  try {
    const { product_id, rating, title, body: reviewBody, order_id } = req.body;
    if (!product_id || !rating || !reviewBody) {
      return sendError(res, 400, 'product_id, rating, and body are required.');
    }
    if (rating < 1 || rating > 5) return sendError(res, 400, 'Rating must be between 1 and 5.');

    const product = await productModel.findById(parseInt(product_id));
    if (!product) return sendError(res, 404, 'Product not found.');

    // One review per user per product
    const existing = await reviewModel.findUserReview(req.user.id, parseInt(product_id));
    if (existing) return sendError(res, 409, 'You have already reviewed this product.');

    // Check if user bought the product (for verified badge)
    let isVerified = 0;
    if (order_id) {
      const [rows] = await query(
        'SELECT oi.id FROM order_items oi JOIN orders o ON o.id = oi.order_id WHERE oi.product_id = ? AND o.user_id = ? AND o.status = "delivered"',
        [product_id, req.user.id]
      );
      isVerified = rows.length ? 1 : 0;
    }

    const review = await reviewModel.create({
      product_id: parseInt(product_id),
      user_id: req.user.id,
      order_id: order_id || null,
      rating: parseInt(rating),
      title: title || null,
      body: reviewBody,
      is_verified: isVerified,
    });

    return sendSuccess(res, 201, 'Review submitted. Thank you!', review);
  } catch (err) { next(err); }
}

/**
 * PUT /api/reviews/:id
 */
async function updateReview(req, res, next) {
  try {
    const { rating, title, body: reviewBody } = req.body;
    if (rating && (rating < 1 || rating > 5)) return sendError(res, 400, 'Rating must be between 1 and 5.');

    const review = await reviewModel.findById(parseInt(req.params.id));
    if (!review) return sendError(res, 404, 'Review not found.');
    if (review.user_id !== req.user.id) return sendError(res, 403, 'Not your review.');

    const updated = await reviewModel.updateById(parseInt(req.params.id), req.user.id, { rating, title, body: reviewBody });
    return sendSuccess(res, 200, 'Review updated.', updated);
  } catch (err) { next(err); }
}

/**
 * DELETE /api/reviews/:id
 */
async function deleteReview(req, res, next) {
  try {
    const review = await reviewModel.findById(parseInt(req.params.id));
    if (!review) return sendError(res, 404, 'Review not found.');
    if (review.user_id !== req.user.id && req.user.role !== 'admin') return sendError(res, 403, 'Forbidden.');

    const deleted = await reviewModel.deleteById(parseInt(req.params.id), review.user_id);
    if (!deleted) return sendError(res, 404, 'Review not found.');
    return sendSuccess(res, 200, 'Review deleted.');
  } catch (err) { next(err); }
}

/**
 * POST /api/reviews/:id/helpful
 */
async function markHelpful(req, res, next) {
  try {
    await reviewModel.incrementHelpful(parseInt(req.params.id));
    return sendSuccess(res, 200, 'Marked as helpful.');
  } catch (err) { next(err); }
}

module.exports = { getProductReviews, createReview, updateReview, deleteReview, markHelpful };
