'use strict';

const userModel    = require('../models/userModel');
const orderModel   = require('../models/orderModel');
const wishlistModel = require('../models/wishlistModel');
const { query } = require('../config/db');
const { sendSuccess, sendError } = require('../utils/responseHelper');

/**
 * GET /api/account/dashboard
 * Returns profile + stats for the account dashboard page.
 */
async function getDashboard(req, res, next) {
  try {
    const userId = req.user.id;

    const [
      user,
      [orderCountRows],
      [pendingRows],
      [totalSpentRows],
      wishlistItems,
    ] = await Promise.all([
      userModel.findById(userId),
      query('SELECT COUNT(*) AS total FROM orders WHERE user_id = ?', [userId]),
      query('SELECT COUNT(*) AS total FROM orders WHERE user_id = ? AND status IN ("pending","confirmed","processing","shipped")', [userId]),
      query('SELECT IFNULL(SUM(total_amount), 0) AS total FROM orders WHERE user_id = ? AND payment_status = "paid"', [userId]),
      wishlistModel.getWishlist(userId),
    ]);

    const recentOrders = await orderModel.getUserOrders(userId, 5, 0);

    return sendSuccess(res, 200, 'Dashboard data fetched.', {
      user,
      stats: {
        total_orders:     orderCountRows[0].total,
        active_orders:    pendingRows[0].total,
        total_spent:      parseFloat(totalSpentRows[0].total).toFixed(2),
        wishlist_count:   wishlistItems.length,
      },
      recent_orders: recentOrders,
    });
  } catch (err) { next(err); }
}

/**
 * GET /api/account/profile
 */
async function getProfile(req, res, next) {
  try {
    const user = await userModel.findById(req.user.id);
    const [addressRows] = await query(
      'SELECT * FROM user_addresses WHERE user_id = ? ORDER BY is_default DESC, id DESC',
      [req.user.id]
    );
    return sendSuccess(res, 200, 'Profile fetched.', { user, addresses: addressRows });
  } catch (err) { next(err); }
}

/**
 * PATCH /api/account/profile
 */
async function updateProfile(req, res, next) {
  try {
    const { name, email } = req.body;
    if (!name || !name.trim()) return sendError(res, 400, 'Name is required.');
    const updated = await userModel.updateById(req.user.id, { name: name.trim(), email: email || null });
    return sendSuccess(res, 200, 'Profile updated.', updated);
  } catch (err) { next(err); }
}

/**
 * GET /api/account/orders
 */
async function getAccountOrders(req, res, next) {
  try {
    const limit  = parseInt(req.query.limit)  || 10;
    const offset = parseInt(req.query.offset) || 0;
    const orders = await orderModel.getUserOrders(req.user.id, limit, offset);
    const total  = await orderModel.countUserOrders(req.user.id);
    return sendSuccess(res, 200, 'Orders fetched.', { orders, total });
  } catch (err) { next(err); }
}

/**
 * GET /api/account/wishlist
 */
async function getAccountWishlist(req, res, next) {
  try {
    const items = await wishlistModel.getWishlist(req.user.id);
    return sendSuccess(res, 200, 'Wishlist fetched.', { items, count: items.length });
  } catch (err) { next(err); }
}

module.exports = { getDashboard, getProfile, updateProfile, getAccountOrders, getAccountWishlist };
