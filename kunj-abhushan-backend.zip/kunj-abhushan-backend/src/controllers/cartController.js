'use strict';

const cartModel = require('../models/cartModel');
const productModel = require('../models/productModel');
const { sendSuccess, sendError } = require('../utils/responseHelper');

/**
 * GET /api/cart
 */
async function getCart(req, res, next) {
  try {
    const cart = await cartModel.getCartWithItems(req.user.id);
    return sendSuccess(res, 200, 'Cart fetched.', cart);
  } catch (err) { next(err); }
}

/**
 * POST /api/cart/items
 * Body: { product_id, qty }
 */
async function addToCart(req, res, next) {
  try {
    const { product_id, qty = 1 } = req.body;
    if (!product_id) return sendError(res, 400, 'product_id is required.');

    const product = await productModel.findById(product_id);
    if (!product) return sendError(res, 404, 'Product not found.');
    if (product.stock_qty < 1) return sendError(res, 400, 'Product is out of stock.');
    if (qty > product.stock_qty) return sendError(res, 400, `Only ${product.stock_qty} units available.`);

    const cart = await cartModel.addItem(req.user.id, product_id, qty);
    return sendSuccess(res, 200, 'Item added to cart.', cart);
  } catch (err) { next(err); }
}

/**
 * PATCH /api/cart/items/:productId
 * Body: { qty }
 */
async function updateCartItem(req, res, next) {
  try {
    const { productId } = req.params;
    const { qty } = req.body;
    if (qty === undefined) return sendError(res, 400, 'qty is required.');

    if (qty > 0) {
      const product = await productModel.findById(parseInt(productId));
      if (!product) return sendError(res, 404, 'Product not found.');
      if (qty > product.stock_qty) return sendError(res, 400, `Only ${product.stock_qty} units available.`);
    }

    const cart = await cartModel.updateItemQty(req.user.id, parseInt(productId), parseInt(qty));
    return sendSuccess(res, 200, qty <= 0 ? 'Item removed from cart.' : 'Cart updated.', cart);
  } catch (err) { next(err); }
}

/**
 * DELETE /api/cart/items/:productId
 */
async function removeFromCart(req, res, next) {
  try {
    const cart = await cartModel.removeItem(req.user.id, parseInt(req.params.productId));
    return sendSuccess(res, 200, 'Item removed from cart.', cart);
  } catch (err) { next(err); }
}

/**
 * DELETE /api/cart
 */
async function clearCart(req, res, next) {
  try {
    await cartModel.clearCart(req.user.id);
    return sendSuccess(res, 200, 'Cart cleared.');
  } catch (err) { next(err); }
}

module.exports = { getCart, addToCart, updateCartItem, removeFromCart, clearCart };
