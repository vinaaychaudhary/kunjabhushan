'use strict';

const wishlistModel = require('../models/wishlistModel');
const productModel  = require('../models/productModel');
const { sendSuccess, sendError } = require('../utils/responseHelper');

/**
 * GET /api/wishlist
 */
async function getWishlist(req, res, next) {
  try {
    const items = await wishlistModel.getWishlist(req.user.id);
    return sendSuccess(res, 200, 'Wishlist fetched.', { items, count: items.length });
  } catch (err) { next(err); }
}

/**
 * POST /api/wishlist
 * Body: { product_id }
 */
async function addToWishlist(req, res, next) {
  try {
    const { product_id } = req.body;
    if (!product_id) return sendError(res, 400, 'product_id is required.');

    const product = await productModel.findById(product_id);
    if (!product) return sendError(res, 404, 'Product not found.');

    await wishlistModel.addItem(req.user.id, product_id);
    return sendSuccess(res, 200, `${product.name} added to wishlist.`);
  } catch (err) { next(err); }
}

/**
 * DELETE /api/wishlist/:productId
 */
async function removeFromWishlist(req, res, next) {
  try {
    const removed = await wishlistModel.removeItem(req.user.id, parseInt(req.params.productId));
    if (!removed) return sendError(res, 404, 'Item not in wishlist.');
    return sendSuccess(res, 200, 'Removed from wishlist.');
  } catch (err) { next(err); }
}

/**
 * POST /api/wishlist/toggle
 * Body: { product_id } — adds if not present, removes if present.
 */
async function toggleWishlist(req, res, next) {
  try {
    const { product_id } = req.body;
    if (!product_id) return sendError(res, 400, 'product_id is required.');

    const inWishlist = await wishlistModel.isInWishlist(req.user.id, product_id);
    if (inWishlist) {
      await wishlistModel.removeItem(req.user.id, product_id);
      return sendSuccess(res, 200, 'Removed from wishlist.', { in_wishlist: false });
    } else {
      const product = await productModel.findById(product_id);
      if (!product) return sendError(res, 404, 'Product not found.');
      await wishlistModel.addItem(req.user.id, product_id);
      return sendSuccess(res, 200, 'Added to wishlist.', { in_wishlist: true });
    }
  } catch (err) { next(err); }
}

/**
 * DELETE /api/wishlist
 */
async function clearWishlist(req, res, next) {
  try {
    await wishlistModel.clearWishlist(req.user.id);
    return sendSuccess(res, 200, 'Wishlist cleared.');
  } catch (err) { next(err); }
}

module.exports = { getWishlist, addToWishlist, removeFromWishlist, toggleWishlist, clearWishlist };
