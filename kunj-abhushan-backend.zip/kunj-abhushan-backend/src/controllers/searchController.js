'use strict';

const { query } = require('../config/db');
const { sendSuccess, sendError, paginate, paginationMeta } = require('../utils/responseHelper');

/**
 * GET /api/search?q=tulsi&page=1&limit=20&category=&min_price=&max_price=&sort=
 * Full-text + LIKE search across products.
 */
async function search(req, res, next) {
  try {
    const q = (req.query.q || '').trim();
    if (!q || q.length < 2) return sendError(res, 400, 'Search query must be at least 2 characters.');

    const { page, limit, offset } = paginate(req.query);
    const { category, min_price, max_price, sort } = req.query;

    const conditions = ['p.is_active = 1'];
    const params     = [];

    // Full-text search or LIKE fallback
    const searchCond = `(MATCH(p.name, p.description, p.short_desc) AGAINST(? IN BOOLEAN MODE) OR p.name LIKE ?)`;
    conditions.push(searchCond);
    params.push(`${q}*`, `%${q}%`);

    if (category) {
      const [catRows] = await query('SELECT id FROM categories WHERE slug = ?', [category]);
      if (catRows.length) { conditions.push('p.category_id = ?'); params.push(catRows[0].id); }
    }
    if (min_price) { conditions.push('p.price >= ?'); params.push(parseFloat(min_price)); }
    if (max_price) { conditions.push('p.price <= ?'); params.push(parseFloat(max_price)); }

    const where = conditions.join(' AND ');
    const sortMap = {
      price_asc:  'p.price ASC',
      price_desc: 'p.price DESC',
      rating:     'p.avg_rating DESC',
      popular:    'p.sold_count DESC',
      newest:     'p.created_at DESC',
    };
    const orderBy = sortMap[sort] || 'p.avg_rating DESC, p.sold_count DESC';

    const baseSelect = `
      p.id, p.name, p.slug, p.short_desc, p.price, p.original_price,
      p.avg_rating, p.review_count, p.stock_qty, p.badge_text, p.badge_color,
      c.name AS category_name, c.slug AS category_slug,
      (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) AS primary_image,
      ROUND(((p.original_price - p.price) / p.original_price) * 100) AS discount_percent
    `;

    const [products] = await query(
      `SELECT ${baseSelect} FROM products p
       JOIN categories c ON c.id = p.category_id
       WHERE ${where}
       ORDER BY ${orderBy}
       LIMIT ? OFFSET ?`,
      [...params, limit, offset]
    );

    const [countRows] = await query(
      `SELECT COUNT(*) AS total FROM products p WHERE ${where}`,
      params
    );

    return sendSuccess(res, 200, `Found ${countRows[0].total} result(s) for "${q}".`, products, paginationMeta(countRows[0].total, page, limit));
  } catch (err) { next(err); }
}

/**
 * GET /api/search/suggestions?q=tul
 * Returns quick name suggestions for autocomplete (max 8 results).
 */
async function suggestions(req, res, next) {
  try {
    const q = (req.query.q || '').trim();
    if (!q || q.length < 2) return sendSuccess(res, 200, 'Suggestions', []);

    const [rows] = await query(
      `SELECT p.id, p.name, p.slug, c.name AS category_name,
              (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) AS primary_image
       FROM products p JOIN categories c ON c.id = p.category_id
       WHERE p.is_active = 1 AND p.name LIKE ?
       ORDER BY p.sold_count DESC LIMIT 8`,
      [`%${q}%`]
    );

    return sendSuccess(res, 200, 'Suggestions fetched.', rows);
  } catch (err) { next(err); }
}

/**
 * GET /api/search/trending
 * Most searched / top sold products as trending suggestions.
 */
async function trending(req, res, next) {
  try {
    const [rows] = await query(
      `SELECT p.id, p.name, p.slug, p.price, p.avg_rating,
              (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) AS primary_image
       FROM products p
       WHERE p.is_active = 1
       ORDER BY p.sold_count DESC, p.avg_rating DESC
       LIMIT 8`
    );
    return sendSuccess(res, 200, 'Trending products fetched.', rows);
  } catch (err) { next(err); }
}

module.exports = { search, suggestions, trending };
