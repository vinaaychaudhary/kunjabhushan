'use strict';

const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const { body } = require('express-validator');
const { validate } = require('../middleware/validationMiddleware');
const userModel = require('../models/userModel');
const { generateOTP, saveOTP, verifyOTP } = require('../utils/otpHelper');
const { generateTokenPair, verifyRefreshToken, generateAccessToken } = require('../utils/jwtHelper');
const { sendOTPSMS } = require('../services/twilioService');
const { sendSuccess, sendError } = require('../utils/responseHelper');
const { query } = require('../config/db');

// ── Auth-specific rate limiter ────────────────────────────────
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: parseInt(process.env.AUTH_RATE_LIMIT_MAX) || 10,
  message: { success: false, message: 'Too many attempts. Try again after 15 minutes.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// ── Validation rules ──────────────────────────────────────────
const mobileRules = [
  body('mobile')
    .trim()
    .notEmpty().withMessage('Mobile number is required.')
    .matches(/^[6-9]\d{9}$/).withMessage('Enter a valid 10-digit Indian mobile number.'),
];

const otpRules = [
  ...mobileRules,
  body('otp')
    .trim()
    .notEmpty().withMessage('OTP is required.')
    .isLength({ min: 6, max: 6 }).withMessage('OTP must be exactly 6 digits.')
    .isNumeric().withMessage('OTP must contain only digits.'),
];

/**
 * POST /api/auth/send-otp
 * Send OTP to mobile number. Works for both login and registration.
 */
async function sendOtp(req, res, next) {
  try {
    const { mobile, purpose = 'login' } = req.body;
    const otp = generateOTP();
    await saveOTP(mobile, otp, purpose);
    const result = await sendOTPSMS(mobile, otp);
    if (!result.success) return sendError(res, 503, result.message);
    return sendSuccess(res, 200, result.message, { mobile });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/auth/verify-otp
 * Verify OTP and log in (or complete registration if user doesn't exist).
 */
async function verifyOtpLogin(req, res, next) {
  try {
    const { mobile, otp, name, email } = req.body;
    const verification = await verifyOTP(mobile, otp, 'login');
    if (!verification.valid) return sendError(res, 400, verification.message);

    let user = await userModel.findByMobile(mobile);

    if (!user) {
      // Auto-register new user
      user = await userModel.create({
        name: name || `User_${mobile.slice(-4)}`,
        email: email || null,
        mobile,
      });
    }

    if (!user.is_active) return sendError(res, 403, 'Your account has been deactivated. Contact support.');

    const { accessToken, refreshToken } = generateTokenPair(user);
    await userModel.updateById(user.id, { refresh_token: refreshToken, last_login: new Date() });

    return sendSuccess(res, 200, 'Login successful.', {
      user: { id: user.id, name: user.name, email: user.email, mobile: user.mobile, role: user.role, avatar_url: user.avatar_url },
      accessToken,
      refreshToken,
    });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/auth/register
 * Traditional register with mobile, name, email.
 */
async function register(req, res, next) {
  try {
    const { mobile, name, email, password } = req.body;
    const existing = await userModel.findByMobile(mobile);
    if (existing) return sendError(res, 409, 'Mobile number already registered. Please log in.');

    const password_hash = password ? await bcrypt.hash(password, 12) : null;
    const user = await userModel.create({ name, email: email || null, mobile, password_hash });

    const otp = generateOTP();
    await saveOTP(mobile, otp, 'verify');
    await sendOTPSMS(mobile, otp);

    return sendSuccess(res, 201, 'Account created. Please verify your mobile with the OTP sent.', {
      user: { id: user.id, name: user.name, mobile: user.mobile },
    });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/auth/login
 * Password-based login (fallback if user has set a password).
 */
async function loginWithPassword(req, res, next) {
  try {
    const { mobile, password } = req.body;
    const user = await userModel.findByMobile(mobile);
    if (!user) return sendError(res, 401, 'Invalid credentials.');
    if (!user.password_hash) return sendError(res, 400, 'This account uses OTP login. Please use OTP to sign in.');
    if (!user.is_active) return sendError(res, 403, 'Account deactivated.');

    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) return sendError(res, 401, 'Invalid credentials.');

    const { accessToken, refreshToken } = generateTokenPair(user);
    await userModel.updateById(user.id, { refresh_token: refreshToken, last_login: new Date() });

    return sendSuccess(res, 200, 'Login successful.', {
      user: { id: user.id, name: user.name, email: user.email, mobile: user.mobile, role: user.role, avatar_url: user.avatar_url },
      accessToken,
      refreshToken,
    });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/auth/refresh
 * Get a new access token using a refresh token.
 */
async function refreshToken(req, res, next) {
  try {
    const { refreshToken: token } = req.body;
    if (!token) return sendError(res, 400, 'Refresh token required.');

    const decoded = verifyRefreshToken(token);
    if (!decoded) return sendError(res, 401, 'Invalid or expired refresh token.');

    const user = await userModel.findById(decoded.id);
    if (!user || !user.is_active) return sendError(res, 401, 'User not found or deactivated.');

    // Optionally verify stored refresh token matches
    const [rows] = await query('SELECT refresh_token FROM users WHERE id = ?', [decoded.id]);
    if (!rows.length || rows[0].refresh_token !== token) {
      return sendError(res, 401, 'Refresh token revoked. Please log in again.');
    }

    const newAccessToken = generateAccessToken(user);
    return sendSuccess(res, 200, 'Token refreshed.', { accessToken: newAccessToken });
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/auth/forgot-password
 * Send OTP for password reset.
 */
async function forgotPassword(req, res, next) {
  try {
    const { mobile } = req.body;
    const user = await userModel.findByMobile(mobile);
    // Always return same message to prevent user enumeration
    if (!user) return sendSuccess(res, 200, 'If this number is registered, you will receive an OTP.');

    const otp = generateOTP();
    await saveOTP(mobile, otp, 'forgot_password');
    await sendOTPSMS(mobile, otp);

    return sendSuccess(res, 200, 'OTP sent for password reset.');
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/auth/reset-password
 * Reset password after OTP verification.
 */
async function resetPassword(req, res, next) {
  try {
    const { mobile, otp, new_password } = req.body;
    const verification = await verifyOTP(mobile, otp, 'forgot_password');
    if (!verification.valid) return sendError(res, 400, verification.message);

    const user = await userModel.findByMobile(mobile);
    if (!user) return sendError(res, 404, 'User not found.');

    const password_hash = await bcrypt.hash(new_password, 12);
    await userModel.updateById(user.id, { password_hash });

    return sendSuccess(res, 200, 'Password reset successfully. Please log in.');
  } catch (err) {
    next(err);
  }
}

/**
 * POST /api/auth/logout
 * Invalidate refresh token.
 */
async function logout(req, res, next) {
  try {
    if (req.user) {
      await userModel.updateById(req.user.id, { refresh_token: null });
    }
    return sendSuccess(res, 200, 'Logged out successfully.');
  } catch (err) {
    next(err);
  }
}

module.exports = {
  sendOtp, verifyOtpLogin, register, loginWithPassword,
  refreshToken, forgotPassword, resetPassword, logout,
  authLimiter, mobileRules, otpRules, validate,
};
