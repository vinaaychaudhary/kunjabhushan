'use strict';

const bcrypt = require('bcryptjs');
const path = require('path');
const userModel = require('../models/userModel');
const { query } = require('../config/db');
const { sendSuccess, sendError } = require('../utils/responseHelper');

/**
 * GET /api/users/me
 */
async function getMe(req, res, next) {
  try {
    const user = await userModel.findById(req.user.id);
    return sendSuccess(res, 200, 'Profile fetched.', user);
  } catch (err) { next(err); }
}

/**
 * PATCH /api/users/me
 */
async function updateMe(req, res, next) {
  try {
    const { name, email } = req.body;
    const updated = await userModel.updateById(req.user.id, { name, email });
    return sendSuccess(res, 200, 'Profile updated.', updated);
  } catch (err) { next(err); }
}

/**
 * PATCH /api/users/me/avatar
 */
async function updateAvatar(req, res, next) {
  try {
    if (!req.file) return sendError(res, 400, 'No image uploaded.');
    const avatarUrl = `/uploads/avatars/${req.file.filename}`;
    const updated = await userModel.updateById(req.user.id, { avatar_url: avatarUrl });
    return sendSuccess(res, 200, 'Avatar updated.', { avatar_url: updated.avatar_url });
  } catch (err) { next(err); }
}

/**
 * PATCH /api/users/me/password
 */
async function changePassword(req, res, next) {
  try {
    const { old_password, new_password } = req.body;
    const [rows] = await query('SELECT password_hash FROM users WHERE id = ?', [req.user.id]);
    if (!rows[0].password_hash) return sendError(res, 400, 'Your account uses OTP login. Password change not applicable.');
    const match = await bcrypt.compare(old_password, rows[0].password_hash);
    if (!match) return sendError(res, 400, 'Current password is incorrect.');
    const hash = await bcrypt.hash(new_password, 12);
    await userModel.updateById(req.user.id, { password_hash: hash });
    return sendSuccess(res, 200, 'Password changed successfully.');
  } catch (err) { next(err); }
}

// ── Addresses ─────────────────────────────────────────────────
/**
 * GET /api/users/me/addresses
 */
async function getAddresses(req, res, next) {
  try {
    const [rows] = await query(
      'SELECT * FROM user_addresses WHERE user_id = ? ORDER BY is_default DESC, id DESC',
      [req.user.id]
    );
    return sendSuccess(res, 200, 'Addresses fetched.', rows);
  } catch (err) { next(err); }
}

/**
 * POST /api/users/me/addresses
 */
async function addAddress(req, res, next) {
  try {
    const { label, full_name, mobile, line1, line2, city, state, pincode, country, is_default } = req.body;

    if (is_default) {
      await query('UPDATE user_addresses SET is_default = 0 WHERE user_id = ?', [req.user.id]);
    }

    const [result] = await query(
      `INSERT INTO user_addresses (user_id, label, full_name, mobile, line1, line2, city, state, pincode, country, is_default)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [req.user.id, label || 'Home', full_name, mobile, line1, line2 || null, city, state, pincode, country || 'India', is_default ? 1 : 0]
    );

    const [rows] = await query('SELECT * FROM user_addresses WHERE id = ?', [result.insertId]);
    return sendSuccess(res, 201, 'Address added.', rows[0]);
  } catch (err) { next(err); }
}

/**
 * PUT /api/users/me/addresses/:id
 */
async function updateAddress(req, res, next) {
  try {
    const { id } = req.params;
    const { label, full_name, mobile, line1, line2, city, state, pincode, country, is_default } = req.body;

    const [existing] = await query('SELECT id FROM user_addresses WHERE id = ? AND user_id = ?', [id, req.user.id]);
    if (!existing.length) return sendError(res, 404, 'Address not found.');

    if (is_default) {
      await query('UPDATE user_addresses SET is_default = 0 WHERE user_id = ?', [req.user.id]);
    }

    await query(
      `UPDATE user_addresses SET label=?, full_name=?, mobile=?, line1=?, line2=?, city=?, state=?, pincode=?, country=?, is_default=? WHERE id=?`,
      [label || 'Home', full_name, mobile, line1, line2 || null, city, state, pincode, country || 'India', is_default ? 1 : 0, id]
    );

    const [rows] = await query('SELECT * FROM user_addresses WHERE id = ?', [id]);
    return sendSuccess(res, 200, 'Address updated.', rows[0]);
  } catch (err) { next(err); }
}

/**
 * DELETE /api/users/me/addresses/:id
 */
async function deleteAddress(req, res, next) {
  try {
    const { id } = req.params;
    const [result] = await query(
      'DELETE FROM user_addresses WHERE id = ? AND user_id = ?',
      [id, req.user.id]
    );
    if (!result.affectedRows) return sendError(res, 404, 'Address not found.');
    return sendSuccess(res, 200, 'Address deleted.');
  } catch (err) { next(err); }
}

/**
 * PATCH /api/users/me/addresses/:id/default
 */
async function setDefaultAddress(req, res, next) {
  try {
    const { id } = req.params;
    const [existing] = await query('SELECT id FROM user_addresses WHERE id = ? AND user_id = ?', [id, req.user.id]);
    if (!existing.length) return sendError(res, 404, 'Address not found.');
    await query('UPDATE user_addresses SET is_default = 0 WHERE user_id = ?', [req.user.id]);
    await query('UPDATE user_addresses SET is_default = 1 WHERE id = ?', [id]);
    return sendSuccess(res, 200, 'Default address updated.');
  } catch (err) { next(err); }
}

module.exports = { getMe, updateMe, updateAvatar, changePassword, getAddresses, addAddress, updateAddress, deleteAddress, setDefaultAddress };
