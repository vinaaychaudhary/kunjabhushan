'use strict';

const express = require('express');
const router  = express.Router();
const { param, body } = require('express-validator');

const {
  getCategories, getCategory, getCategoryProducts,
  createCategory, updateCategory, deleteCategory,
} = require('../controllers/categoryController');

const { protect, adminOnly } = require('../middleware/authMiddleware');
const { validate } = require('../middleware/validationMiddleware');
const { uploadCategoryImage } = require('../middleware/uploadMiddleware');

// ── Public ────────────────────────────────────────────────────
router.get('/', getCategories);
router.get('/:slugOrId', getCategory);
router.get('/:slugOrId/products', getCategoryProducts);

// ── Admin ─────────────────────────────────────────────────────
router.post(
  '/',
  protect, adminOnly,
  uploadCategoryImage,
  [body('name').trim().notEmpty().withMessage('Category name is required.')],
  validate,
  createCategory
);

router.put(
  '/:id',
  protect, adminOnly,
  uploadCategoryImage,
  [param('id').isInt()],
  validate,
  updateCategory
);

router.delete('/:id', protect, adminOnly, [param('id').isInt()], validate, deleteCategory);

module.exports = router;
