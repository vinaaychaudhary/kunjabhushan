'use strict';

const express = require('express');
const router  = express.Router();
const { body, param, query } = require('express-validator');

const {
  getMyOrders, getOrder, createOrder, cancelOrder,
  getAllOrders, updateOrderStatus,
} = require('../controllers/orderController');

const { protect, adminOnly } = require('../middleware/authMiddleware');
const { validate } = require('../middleware/validationMiddleware');

// All order routes require authentication
router.use(protect);

// ── Customer routes ───────────────────────────────────────────
router.get(
  '/',
  [
    query('page').optional().isInt({ min: 1 }),
    query('limit').optional().isInt({ min: 1, max: 50 }),
  ],
  validate,
  getMyOrders
);

router.post(
  '/',
  [
    body('address_id').isInt({ min: 1 }).withMessage('Valid address_id is required.'),
    body('payment_method')
      .optional()
      .isIn(['razorpay', 'cod', 'upi', 'card', 'netbanking'])
      .withMessage('Invalid payment method.'),
    body('coupon_code').optional().trim().isLength({ max: 30 }),
    body('notes').optional().trim().isLength({ max: 500 }),
  ],
  validate,
  createOrder
);

router.get('/:id', [param('id').isInt()], validate, getOrder);

router.post(
  '/:id/cancel',
  [
    param('id').isInt(),
    body('reason').optional().trim().isLength({ max: 300 }),
  ],
  validate,
  cancelOrder
);

// ── Admin routes ──────────────────────────────────────────────
router.get('/admin/all', adminOnly, getAllOrders);

router.patch(
  '/:id/status',
  adminOnly,
  [
    param('id').isInt(),
    body('status')
      .isIn(['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded'])
      .withMessage('Invalid status value.'),
    body('tracking_number').optional().trim().isLength({ max: 100 }),
    body('courier_name').optional().trim().isLength({ max: 100 }),
  ],
  validate,
  updateOrderStatus
);

module.exports = router;
