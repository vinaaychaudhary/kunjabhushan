'use strict';

const express = require('express');
const router  = express.Router();
const { body, param } = require('express-validator');

const {
  getMe, updateMe, updateAvatar, changePassword,
  getAddresses, addAddress, updateAddress, deleteAddress, setDefaultAddress,
} = require('../controllers/userController');
const { protect } = require('../middleware/authMiddleware');
const { validate } = require('../middleware/validationMiddleware');
const { uploadAvatar } = require('../middleware/uploadMiddleware');

// All user routes require authentication
router.use(protect);

// ── Profile ───────────────────────────────────────────────────
router.get('/me', getMe);

router.patch(
  '/me',
  [
    body('name').optional().trim().isLength({ min: 2, max: 100 }).withMessage('Name must be 2–100 characters.'),
    body('email').optional({ checkFalsy: true }).trim().isEmail().withMessage('Invalid email address.'),
  ],
  validate,
  updateMe
);

router.patch('/me/avatar', uploadAvatar, updateAvatar);

router.patch(
  '/me/password',
  [
    body('old_password').notEmpty().withMessage('Current password is required.'),
    body('new_password').isLength({ min: 6 }).withMessage('New password must be at least 6 characters.'),
  ],
  validate,
  changePassword
);

// ── Addresses ─────────────────────────────────────────────────
const addressRules = [
  body('full_name').trim().notEmpty().withMessage('Full name is required.'),
  body('mobile').trim().matches(/^[6-9]\d{9}$/).withMessage('Enter a valid 10-digit mobile number.'),
  body('line1').trim().notEmpty().withMessage('Address line 1 is required.'),
  body('city').trim().notEmpty().withMessage('City is required.'),
  body('state').trim().notEmpty().withMessage('State is required.'),
  body('pincode').trim().matches(/^\d{6}$/).withMessage('Enter a valid 6-digit pincode.'),
];

router.get('/me/addresses', getAddresses);
router.post('/me/addresses', addressRules, validate, addAddress);
router.put('/me/addresses/:id', [param('id').isInt(), ...addressRules], validate, updateAddress);
router.delete('/me/addresses/:id', [param('id').isInt()], validate, deleteAddress);
router.patch('/me/addresses/:id/default', [param('id').isInt()], validate, setDefaultAddress);

module.exports = router;
