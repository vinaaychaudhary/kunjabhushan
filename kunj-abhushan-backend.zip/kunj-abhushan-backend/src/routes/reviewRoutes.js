'use strict';

const express = require('express');
const router  = express.Router();
const { body, param, query } = require('express-validator');

const {
  getProductReviews, createReview, updateReview, deleteReview, markHelpful,
} = require('../controllers/reviewController');

const { protect, optionalAuth } = require('../middleware/authMiddleware');
const { validate } = require('../middleware/validationMiddleware');

// GET /api/reviews/product/:productId  — public
router.get(
  '/product/:productId',
  [
    param('productId').isInt({ min: 1 }).withMessage('Valid productId is required.'),
    query('page').optional().isInt({ min: 1 }),
    query('limit').optional().isInt({ min: 1, max: 50 }),
  ],
  validate,
  getProductReviews
);

// POST /api/reviews  — authenticated
router.post(
  '/',
  protect,
  [
    body('product_id').isInt({ min: 1 }).withMessage('Valid product_id is required.'),
    body('rating').isInt({ min: 1, max: 5 }).withMessage('Rating must be between 1 and 5.'),
    body('body').trim().notEmpty().withMessage('Review body is required.')
      .isLength({ min: 10, max: 2000 }).withMessage('Review must be 10–2000 characters.'),
    body('title').optional().trim().isLength({ max: 150 }),
    body('order_id').optional().isInt({ min: 1 }),
  ],
  validate,
  createReview
);

// PUT /api/reviews/:id  — authenticated (own review)
router.put(
  '/:id',
  protect,
  [
    param('id').isInt({ min: 1 }),
    body('rating').optional().isInt({ min: 1, max: 5 }).withMessage('Rating must be between 1 and 5.'),
    body('body').optional().trim().isLength({ min: 10, max: 2000 }),
    body('title').optional().trim().isLength({ max: 150 }),
  ],
  validate,
  updateReview
);

// DELETE /api/reviews/:id  — authenticated (own review or admin)
router.delete('/:id', protect, [param('id').isInt()], validate, deleteReview);

// POST /api/reviews/:id/helpful  — optional auth
router.post('/:id/helpful', optionalAuth, [param('id').isInt()], validate, markHelpful);

module.exports = router;
