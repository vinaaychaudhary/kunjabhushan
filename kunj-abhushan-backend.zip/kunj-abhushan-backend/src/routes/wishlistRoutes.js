'use strict';

const express = require('express');
const router  = express.Router();
const { body, param } = require('express-validator');

const {
  getWishlist, addToWishlist, removeFromWishlist, toggleWishlist, clearWishlist,
} = require('../controllers/wishlistController');

const { protect } = require('../middleware/authMiddleware');
const { validate } = require('../middleware/validationMiddleware');

// All wishlist routes require authentication
router.use(protect);

router.get('/', getWishlist);

router.post(
  '/',
  [body('product_id').isInt({ min: 1 }).withMessage('Valid product_id is required.')],
  validate,
  addToWishlist
);

router.post(
  '/toggle',
  [body('product_id').isInt({ min: 1 }).withMessage('Valid product_id is required.')],
  validate,
  toggleWishlist
);

router.delete('/:productId', [param('productId').isInt()], validate, removeFromWishlist);

router.delete('/', clearWishlist);

module.exports = router;
