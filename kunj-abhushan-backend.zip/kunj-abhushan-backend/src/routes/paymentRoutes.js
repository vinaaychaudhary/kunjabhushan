'use strict';

const express = require('express');
const router  = express.Router();
const { body, param } = require('express-validator');

const {
  createPaymentOrder, verifyPayment, handleWebhook, getPaymentStatus,
} = require('../controllers/paymentController');

const { protect } = require('../middleware/authMiddleware');
const { validate } = require('../middleware/validationMiddleware');

// Razorpay webhook — raw body, no JWT (signature verified inside handler)
router.post('/webhook', handleWebhook);

// All other payment routes require authentication
router.use(protect);

// POST /api/payment/create-order
router.post(
  '/create-order',
  [body('order_id').isInt({ min: 1 }).withMessage('Valid order_id is required.')],
  validate,
  createPaymentOrder
);

// POST /api/payment/verify
router.post(
  '/verify',
  [
    body('razorpay_order_id').notEmpty().withMessage('razorpay_order_id is required.'),
    body('razorpay_payment_id').notEmpty().withMessage('razorpay_payment_id is required.'),
    body('razorpay_signature').notEmpty().withMessage('razorpay_signature is required.'),
    body('order_id').isInt({ min: 1 }).withMessage('Valid order_id is required.'),
  ],
  validate,
  verifyPayment
);

// GET /api/payment/status/:orderId
router.get(
  '/status/:orderId',
  [param('orderId').isInt({ min: 1 })],
  validate,
  getPaymentStatus
);

module.exports = router;
