'use strict';

const express = require('express');
const router  = express.Router();
const { body, query } = require('express-validator');

const {
  getDashboard, getProfile, updateProfile, getAccountOrders, getAccountWishlist,
} = require('../controllers/accountController');

const { protect } = require('../middleware/authMiddleware');
const { validate } = require('../middleware/validationMiddleware');

// All account routes require authentication
router.use(protect);

// GET /api/account/dashboard
router.get('/dashboard', getDashboard);

// GET /api/account/profile
router.get('/profile', getProfile);

// PATCH /api/account/profile
router.patch(
  '/profile',
  [
    body('name').trim().notEmpty().withMessage('Name is required.')
      .isLength({ min: 2, max: 100 }).withMessage('Name must be 2–100 characters.'),
    body('email').optional({ checkFalsy: true }).trim().isEmail().withMessage('Invalid email address.'),
  ],
  validate,
  updateProfile
);

// GET /api/account/orders
router.get(
  '/orders',
  [
    query('limit').optional().isInt({ min: 1, max: 50 }),
    query('offset').optional().isInt({ min: 0 }),
  ],
  validate,
  getAccountOrders
);

// GET /api/account/wishlist
router.get('/wishlist', getAccountWishlist);

module.exports = router;
