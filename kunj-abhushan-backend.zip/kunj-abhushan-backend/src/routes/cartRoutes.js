'use strict';

const express = require('express');
const router  = express.Router();
const { body, param } = require('express-validator');

const {
  getCart, addToCart, updateCartItem, removeFromCart, clearCart,
} = require('../controllers/cartController');

const { protect } = require('../middleware/authMiddleware');
const { validate } = require('../middleware/validationMiddleware');

// All cart routes require authentication
router.use(protect);

router.get('/', getCart);

router.post(
  '/items',
  [
    body('product_id').isInt({ min: 1 }).withMessage('Valid product_id is required.'),
    body('qty').optional().isInt({ min: 1, max: 50 }).withMessage('Quantity must be between 1 and 50.'),
  ],
  validate,
  addToCart
);

router.patch(
  '/items/:productId',
  [
    param('productId').isInt({ min: 1 }).withMessage('Valid productId is required.'),
    body('qty').isInt({ min: 0 }).withMessage('qty must be a non-negative integer.'),
  ],
  validate,
  updateCartItem
);

router.delete('/items/:productId', [param('productId').isInt()], validate, removeFromCart);

router.delete('/', clearCart);

module.exports = router;
