'use strict';

const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const rateLimit = require('express-rate-limit');

const {
  sendOtp, verifyOtpLogin, register, loginWithPassword,
  refreshToken, forgotPassword, resetPassword, logout,
} = require('../controllers/authController');
const { protect } = require('../middleware/authMiddleware');
const { validate } = require('../middleware/validationMiddleware');

// Strict rate limiter for auth endpoints
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: parseInt(process.env.AUTH_RATE_LIMIT_MAX) || 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, message: 'Too many attempts. Please try again after 15 minutes.' },
});

const mobileVal = body('mobile')
  .trim()
  .notEmpty().withMessage('Mobile number is required.')
  .matches(/^[6-9]\d{9}$/).withMessage('Enter a valid 10-digit Indian mobile number.');

// POST /api/auth/send-otp
router.post(
  '/send-otp',
  authLimiter,
  [mobileVal, body('purpose').optional().isIn(['login','register','forgot_password','verify'])],
  validate,
  sendOtp
);

// POST /api/auth/verify-otp  (login / auto-register)
router.post(
  '/verify-otp',
  authLimiter,
  [
    mobileVal,
    body('otp').trim().notEmpty().withMessage('OTP is required.')
      .isLength({ min: 6, max: 6 }).withMessage('OTP must be 6 digits.')
      .isNumeric().withMessage('OTP must be numeric.'),
    body('name').optional().trim().isLength({ min: 2 }).withMessage('Name must be at least 2 characters.'),
    body('email').optional().trim().isEmail().withMessage('Invalid email address.'),
  ],
  validate,
  verifyOtpLogin
);

// POST /api/auth/register  (name + mobile [+ email + password])
router.post(
  '/register',
  authLimiter,
  [
    body('name').trim().notEmpty().withMessage('Name is required.')
      .isLength({ min: 2, max: 100 }).withMessage('Name must be 2–100 characters.'),
    mobileVal,
    body('email').optional({ checkFalsy: true }).trim().isEmail().withMessage('Invalid email address.'),
    body('password').optional({ checkFalsy: true })
      .isLength({ min: 6 }).withMessage('Password must be at least 6 characters.'),
  ],
  validate,
  register
);

// POST /api/auth/login  (password-based)
router.post(
  '/login',
  authLimiter,
  [
    mobileVal,
    body('password').notEmpty().withMessage('Password is required.'),
  ],
  validate,
  loginWithPassword
);

// POST /api/auth/refresh
router.post(
  '/refresh',
  [body('refreshToken').notEmpty().withMessage('Refresh token is required.')],
  validate,
  refreshToken
);

// POST /api/auth/forgot-password
router.post(
  '/forgot-password',
  authLimiter,
  [mobileVal],
  validate,
  forgotPassword
);

// POST /api/auth/reset-password
router.post(
  '/reset-password',
  authLimiter,
  [
    mobileVal,
    body('otp').trim().notEmpty().withMessage('OTP is required.')
      .isLength({ min: 6, max: 6 }).isNumeric().withMessage('OTP must be 6 digits.'),
    body('new_password').isLength({ min: 6 }).withMessage('Password must be at least 6 characters.'),
  ],
  validate,
  resetPassword
);

// POST /api/auth/logout  (requires token)
router.post('/logout', protect, logout);

module.exports = router;
