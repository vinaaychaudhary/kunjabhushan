'use strict';

const express = require('express');
const router  = express.Router();
const { param, body, query } = require('express-validator');

const {
  getProducts, getFeaturedProducts, getBestsellers, getNewArrivals,
  getProduct, getRelatedProducts,
  createProduct, updateProduct, deleteProduct,
  addProductImage, deleteProductImage,
} = require('../controllers/productController');

const { protect, adminOnly, optionalAuth } = require('../middleware/authMiddleware');
const { validate } = require('../middleware/validationMiddleware');
const { uploadProductImage, uploadProductImages } = require('../middleware/uploadMiddleware');

// ── Public routes ─────────────────────────────────────────────
router.get('/', [
  query('page').optional().isInt({ min: 1 }),
  query('limit').optional().isInt({ min: 1, max: 100 }),
  query('min_price').optional().isFloat({ min: 0 }),
  query('max_price').optional().isFloat({ min: 0 }),
], validate, getProducts);

router.get('/featured',     getFeaturedProducts);
router.get('/bestsellers',  getBestsellers);
router.get('/new-arrivals', getNewArrivals);

router.get('/:slugOrId', optionalAuth, getProduct);
router.get('/:id/related', [param('id').isInt()], validate, getRelatedProducts);

// ── Admin routes ──────────────────────────────────────────────
router.post(
  '/',
  protect, adminOnly,
  uploadProductImage,
  [
    body('name').trim().notEmpty().withMessage('Product name is required.'),
    body('price').isFloat({ min: 0 }).withMessage('Price must be a positive number.'),
    body('category_id').isInt({ min: 1 }).withMessage('Valid category_id is required.'),
    body('stock_qty').optional().isInt({ min: 0 }),
  ],
  validate,
  createProduct
);

router.put(
  '/:id',
  protect, adminOnly,
  [
    param('id').isInt(),
    body('price').optional().isFloat({ min: 0 }),
    body('stock_qty').optional().isInt({ min: 0 }),
    body('category_id').optional().isInt({ min: 1 }),
  ],
  validate,
  updateProduct
);

router.delete('/:id', protect, adminOnly, [param('id').isInt()], validate, deleteProduct);

// Product images (admin)
router.post('/:id/images',              protect, adminOnly, uploadProductImage,  addProductImage);
router.delete('/:id/images/:imageId',   protect, adminOnly, deleteProductImage);

module.exports = router;
