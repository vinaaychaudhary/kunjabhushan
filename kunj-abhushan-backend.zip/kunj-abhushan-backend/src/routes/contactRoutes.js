'use strict';

const express = require('express');
const router  = express.Router();
const { body, param, query } = require('express-validator');
const rateLimit = require('express-rate-limit');

const {
  submitContact, getAllMessages, updateMessageStatus, deleteMessage,
} = require('../controllers/contactController');

const { protect, adminOnly } = require('../middleware/authMiddleware');
const { validate } = require('../middleware/validationMiddleware');

// Strict rate limit on contact form (prevents spam)
const contactLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 5,
  message: { success: false, message: 'Too many messages sent. Please try again after an hour.' },
  standardHeaders: true,
  legacyHeaders: false,
});

// POST /api/contact  — public
router.post(
  '/',
  contactLimiter,
  [
    body('name').trim().notEmpty().withMessage('Name is required.')
      .isLength({ min: 2, max: 100 }).withMessage('Name must be 2–100 characters.'),
    body('email').trim().notEmpty().withMessage('Email is required.')
      .isEmail().withMessage('Invalid email address.'),
    body('mobile').optional({ checkFalsy: true })
      .matches(/^[6-9]\d{9}$/).withMessage('Enter a valid 10-digit mobile number.'),
    body('subject').optional().trim().isLength({ max: 200 }),
    body('message').trim().notEmpty().withMessage('Message is required.')
      .isLength({ min: 10, max: 2000 }).withMessage('Message must be 10–2000 characters.'),
  ],
  validate,
  submitContact
);

// ── Admin routes ──────────────────────────────────────────────
router.get(
  '/',
  protect, adminOnly,
  [
    query('status').optional().isIn(['unread', 'read', 'replied', 'closed']),
    query('page').optional().isInt({ min: 1 }),
    query('limit').optional().isInt({ min: 1, max: 100 }),
  ],
  validate,
  getAllMessages
);

router.patch(
  '/:id/status',
  protect, adminOnly,
  [
    param('id').isInt(),
    body('status').isIn(['unread', 'read', 'replied', 'closed']).withMessage('Invalid status.'),
    body('admin_notes').optional().trim().isLength({ max: 1000 }),
  ],
  validate,
  updateMessageStatus
);

router.delete('/:id', protect, adminOnly, [param('id').isInt()], validate, deleteMessage);

module.exports = router;
