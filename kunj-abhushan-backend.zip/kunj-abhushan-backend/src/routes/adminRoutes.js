'use strict';

const express = require('express');
const router  = express.Router();
const { body, param, query } = require('express-validator');

const {
  getDashboardStats, getAllUsers, updateUser,
  getCoupons, createCoupon, updateCoupon, deleteCoupon,
  getRevenueAnalytics, getTopProducts,
} = require('../controllers/adminController');

const { protect, adminOnly } = require('../middleware/authMiddleware');
const { validate } = require('../middleware/validationMiddleware');

// All admin routes require authentication + admin role
router.use(protect, adminOnly);

// ── Dashboard ─────────────────────────────────────────────────
router.get('/dashboard', getDashboardStats);

// ── Analytics ─────────────────────────────────────────────────
router.get('/analytics/revenue',      getRevenueAnalytics);
router.get('/analytics/top-products', getTopProducts);

// ── Users ─────────────────────────────────────────────────────
router.get(
  '/users',
  [
    query('page').optional().isInt({ min: 1 }),
    query('limit').optional().isInt({ min: 1, max: 100 }),
    query('role').optional().isIn(['customer', 'admin']),
    query('search').optional().trim().isLength({ min: 1 }),
  ],
  validate,
  getAllUsers
);

router.patch(
  '/users/:id',
  [
    param('id').isInt({ min: 1 }),
    body('is_active').optional().isBoolean(),
    body('role').optional().isIn(['customer', 'admin']),
  ],
  validate,
  updateUser
);

// ── Coupons ───────────────────────────────────────────────────
router.get('/coupons', getCoupons);

router.post(
  '/coupons',
  [
    body('code').trim().notEmpty().withMessage('Coupon code is required.')
      .isLength({ min: 3, max: 30 }).withMessage('Code must be 3–30 characters.')
      .isAlphanumeric().withMessage('Code must be alphanumeric.'),
    body('type').isIn(['percent', 'flat']).withMessage('type must be "percent" or "flat".'),
    body('value').isFloat({ min: 0.01 }).withMessage('Value must be greater than 0.'),
    body('min_order_value').optional().isFloat({ min: 0 }),
    body('max_discount').optional().isFloat({ min: 0 }),
    body('usage_limit').optional().isInt({ min: 1 }),
    body('valid_from').optional().isISO8601().withMessage('valid_from must be a valid date.'),
    body('valid_until').optional().isISO8601().withMessage('valid_until must be a valid date.'),
  ],
  validate,
  createCoupon
);

router.patch(
  '/coupons/:id',
  [
    param('id').isInt(),
    body('type').optional().isIn(['percent', 'flat']),
    body('value').optional().isFloat({ min: 0.01 }),
    body('is_active').optional().isBoolean(),
  ],
  validate,
  updateCoupon
);

router.delete('/coupons/:id', [param('id').isInt()], validate, deleteCoupon);

module.exports = router;
