'use strict';

const express = require('express');
const router  = express.Router();
const { query } = require('express-validator');

const { search, suggestions, trending } = require('../controllers/searchController');
const { validate } = require('../middleware/validationMiddleware');

// GET /api/search?q=tulsi&page=1&limit=20&category=&sort=
router.get(
  '/',
  [
    query('q').trim().notEmpty().withMessage('Search query is required.')
      .isLength({ min: 2 }).withMessage('Query must be at least 2 characters.'),
    query('page').optional().isInt({ min: 1 }),
    query('limit').optional().isInt({ min: 1, max: 60 }),
    query('min_price').optional().isFloat({ min: 0 }),
    query('max_price').optional().isFloat({ min: 0 }),
    query('sort').optional().isIn(['price_asc', 'price_desc', 'rating', 'popular', 'newest']),
  ],
  validate,
  search
);

// GET /api/search/suggestions?q=tul  — autocomplete
router.get(
  '/suggestions',
  [query('q').trim().notEmpty().withMessage('Query is required.')],
  validate,
  suggestions
);

// GET /api/search/trending
router.get('/trending', trending);

module.exports = router;
