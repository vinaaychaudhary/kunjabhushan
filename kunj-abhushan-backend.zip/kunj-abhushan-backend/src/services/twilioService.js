'use strict';

let twilioClient = null;

function getClient() {
  if (!twilioClient) {
    const twilio = require('twilio');
    twilioClient = twilio(
      process.env.TWILIO_ACCOUNT_SID,
      process.env.TWILIO_AUTH_TOKEN
    );
  }
  return twilioClient;
}

/**
 * Send an OTP SMS via Twilio.
 * In development, just logs the OTP instead of sending.
 * @param {string} mobile - 10-digit Indian mobile number
 * @param {string} otp
 * @returns {Promise<{success: boolean, message: string}>}
 */
async function sendOTPSMS(mobile, otp) {
  const formattedNumber = mobile.startsWith('+') ? mobile : `+91${mobile}`;
  const body = `Your Kunj Abhushan OTP is: ${otp}. Valid for ${process.env.OTP_EXPIRY_MINUTES || 10} minutes. Do not share this with anyone.`;

  if (process.env.NODE_ENV !== 'production') {
    console.log(`\n📱 [DEV OTP] Mobile: ${formattedNumber} | OTP: ${otp}\n`);
    return { success: true, message: 'OTP sent (dev mode — check console).' };
  }

  try {
    const client = getClient();
    await client.messages.create({
      body,
      from: process.env.TWILIO_PHONE_NUMBER,
      to: formattedNumber,
    });
    return { success: true, message: 'OTP sent successfully.' };
  } catch (err) {
    console.error('Twilio SMS error:', err.message);
    return { success: false, message: 'Failed to send OTP. Please try again.' };
  }
}

module.exports = { sendOTPSMS };
