'use strict';

const Razorpay = require('razorpay');
const crypto = require('crypto');

let razorpayInstance = null;

function getInstance() {
  if (!razorpayInstance) {
    razorpayInstance = new Razorpay({
      key_id:     process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET,
    });
  }
  return razorpayInstance;
}

/**
 * Create a Razorpay order.
 * @param {number} amountInRupees
 * @param {string} receipt - unique receipt id (order_number)
 * @param {Object} notes
 */
async function createRazorpayOrder(amountInRupees, receipt, notes = {}) {
  const instance = getInstance();
  const order = await instance.orders.create({
    amount:   Math.round(amountInRupees * 100), // paise
    currency: 'INR',
    receipt,
    notes,
  });
  return order;
}

/**
 * Verify Razorpay payment signature.
 * Returns true if signature is valid.
 */
function verifyPaymentSignature({ razorpay_order_id, razorpay_payment_id, razorpay_signature }) {
  const body = `${razorpay_order_id}|${razorpay_payment_id}`;
  const expected = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
    .update(body)
    .digest('hex');
  return expected === razorpay_signature;
}

/**
 * Verify Razorpay webhook signature.
 */
function verifyWebhookSignature(rawBody, signature) {
  const expected = crypto
    .createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET)
    .update(rawBody)
    .digest('hex');
  return expected === signature;
}

/**
 * Fetch payment details from Razorpay.
 */
async function fetchPayment(paymentId) {
  const instance = getInstance();
  return instance.payments.fetch(paymentId);
}

/**
 * Initiate a refund.
 */
async function initiateRefund(paymentId, amountInRupees) {
  const instance = getInstance();
  return instance.payments.refund(paymentId, {
    amount: Math.round(amountInRupees * 100),
  });
}

module.exports = {
  createRazorpayOrder,
  verifyPaymentSignature,
  verifyWebhookSignature,
  fetchPayment,
  initiateRefund,
};
