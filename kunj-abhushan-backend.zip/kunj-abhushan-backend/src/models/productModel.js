'use strict';

const { query } = require('../config/db');

const BASE_SELECT = `
  p.id, p.sku, p.name, p.slug, p.short_desc, p.description,
  p.price, p.original_price, p.stock_qty, p.is_active,
  p.is_featured, p.is_bestseller, p.is_new_arrival,
  p.badge_text, p.badge_color, p.avg_rating, p.review_count,
  p.sold_count, p.weight_grams, p.sort_order, p.created_at,
  c.id AS category_id, c.name AS category_name, c.slug AS category_slug,
  (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) AS primary_image,
  ROUND(((p.original_price - p.price) / p.original_price) * 100) AS discount_percent
`;

async function findById(id) {
  const [rows] = await query(
    `SELECT ${BASE_SELECT} FROM products p JOIN categories c ON p.category_id = c.id WHERE p.id = ? AND p.is_active = 1`,
    [id]
  );
  if (!rows.length) return null;
  const product = rows[0];
  product.images = await getImages(id);
  return product;
}

async function findBySlug(slug) {
  const [rows] = await query(
    `SELECT ${BASE_SELECT} FROM products p JOIN categories c ON p.category_id = c.id WHERE p.slug = ? AND p.is_active = 1`,
    [slug]
  );
  if (!rows.length) return null;
  const product = rows[0];
  product.images = await getImages(product.id);
  return product;
}

async function getImages(productId) {
  const [rows] = await query(
    'SELECT id, image_url, alt_text, is_primary, sort_order FROM product_images WHERE product_id = ? ORDER BY sort_order ASC',
    [productId]
  );
  return rows;
}

async function findAll({ where = '', params = [], limit = 20, offset = 0, orderBy = 'p.sort_order ASC, p.id DESC' } = {}) {
  const whereClause = where ? `AND ${where}` : '';
  const [rows] = await query(
    `SELECT ${BASE_SELECT} FROM products p JOIN categories c ON p.category_id = c.id
     WHERE p.is_active = 1 ${whereClause} ORDER BY ${orderBy} LIMIT ? OFFSET ?`,
    [...params, limit, offset]
  );
  return rows;
}

async function countAll({ where = '', params = [] } = {}) {
  const whereClause = where ? `AND ${where}` : '';
  const [rows] = await query(
    `SELECT COUNT(*) AS total FROM products p JOIN categories c ON p.category_id = c.id
     WHERE p.is_active = 1 ${whereClause}`,
    params
  );
  return rows[0].total;
}

async function findRelated(categoryId, excludeId, limit = 8) {
  const [rows] = await query(
    `SELECT ${BASE_SELECT} FROM products p JOIN categories c ON p.category_id = c.id
     WHERE p.is_active = 1 AND p.category_id = ? AND p.id != ?
     ORDER BY p.avg_rating DESC, p.sold_count DESC LIMIT ?`,
    [categoryId, excludeId, limit]
  );
  return rows;
}

async function create(data) {
  const [result] = await query(
    `INSERT INTO products (sku, name, slug, description, short_desc, category_id, price, original_price,
      stock_qty, is_featured, is_bestseller, is_new_arrival, badge_text, badge_color, weight_grams,
      meta_title, meta_desc, sort_order)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      data.sku, data.name, data.slug, data.description, data.short_desc, data.category_id,
      data.price, data.original_price || null, data.stock_qty || 0,
      data.is_featured || 0, data.is_bestseller || 0, data.is_new_arrival || 0,
      data.badge_text || null, data.badge_color || null, data.weight_grams || null,
      data.meta_title || null, data.meta_desc || null, data.sort_order || 0,
    ]
  );
  return findById(result.insertId);
}

async function updateById(id, data) {
  const allowed = [
    'name', 'slug', 'description', 'short_desc', 'category_id', 'price', 'original_price',
    'stock_qty', 'is_featured', 'is_bestseller', 'is_new_arrival', 'is_active',
    'badge_text', 'badge_color', 'weight_grams', 'meta_title', 'meta_desc', 'sort_order',
  ];
  const updates = [];
  const values  = [];
  for (const [k, v] of Object.entries(data)) {
    if (allowed.includes(k)) { updates.push(`${k} = ?`); values.push(v); }
  }
  if (!updates.length) return findById(id);
  values.push(id);
  await query(`UPDATE products SET ${updates.join(', ')} WHERE id = ?`, values);
  return findById(id);
}

async function addImage(productId, imageUrl, altText, isPrimary = false) {
  if (isPrimary) {
    await query('UPDATE product_images SET is_primary = 0 WHERE product_id = ?', [productId]);
  }
  const [result] = await query(
    'INSERT INTO product_images (product_id, image_url, alt_text, is_primary) VALUES (?, ?, ?, ?)',
    [productId, imageUrl, altText || null, isPrimary ? 1 : 0]
  );
  return result.insertId;
}

async function deleteImage(imageId, productId) {
  await query('DELETE FROM product_images WHERE id = ? AND product_id = ?', [imageId, productId]);
}

async function decrementStock(productId, qty, conn) {
  const db = conn || { execute: async (sql, params) => query(sql, params) };
  await db.execute(
    'UPDATE products SET stock_qty = stock_qty - ?, sold_count = sold_count + ? WHERE id = ? AND stock_qty >= ?',
    [qty, qty, productId, qty]
  );
}

module.exports = {
  findById, findBySlug, getImages, findAll, countAll,
  findRelated, create, updateById, addImage, deleteImage, decrementStock,
};
