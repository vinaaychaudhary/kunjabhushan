'use strict';

const { query } = require('../config/db');

async function getProductReviews(productId, limit = 20, offset = 0) {
  const [rows] = await query(
    `SELECT r.id, r.rating, r.title, r.body, r.is_verified, r.helpful_count, r.created_at,
            u.name AS reviewer_name, u.avatar_url AS reviewer_avatar
     FROM reviews r
     JOIN users u ON u.id = r.user_id
     WHERE r.product_id = ? AND r.is_approved = 1
     ORDER BY r.created_at DESC
     LIMIT ? OFFSET ?`,
    [productId, limit, offset]
  );
  return rows;
}

async function countProductReviews(productId) {
  const [rows] = await query(
    'SELECT COUNT(*) AS total FROM reviews WHERE product_id = ? AND is_approved = 1',
    [productId]
  );
  return rows[0].total;
}

async function getRatingDistribution(productId) {
  const [rows] = await query(
    `SELECT rating, COUNT(*) AS count FROM reviews WHERE product_id = ? AND is_approved = 1 GROUP BY rating ORDER BY rating DESC`,
    [productId]
  );
  const dist = { 5: 0, 4: 0, 3: 0, 2: 0, 1: 0 };
  rows.forEach(r => { dist[r.rating] = r.count; });
  return dist;
}

async function findUserReview(userId, productId) {
  const [rows] = await query(
    'SELECT * FROM reviews WHERE user_id = ? AND product_id = ?',
    [userId, productId]
  );
  return rows[0] || null;
}

async function create(data) {
  const [result] = await query(
    'INSERT INTO reviews (product_id, user_id, order_id, rating, title, body, is_verified) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [data.product_id, data.user_id, data.order_id || null, data.rating, data.title || null, data.body, data.is_verified || 0]
  );
  return findById(result.insertId);
}

async function findById(id) {
  const [rows] = await query('SELECT * FROM reviews WHERE id = ?', [id]);
  return rows[0] || null;
}

async function updateById(id, userId, data) {
  const allowed = ['rating', 'title', 'body'];
  const updates = [];
  const values  = [];
  for (const [k, v] of Object.entries(data)) {
    if (allowed.includes(k)) { updates.push(`${k} = ?`); values.push(v); }
  }
  if (!updates.length) return findById(id);
  values.push(id, userId);
  await query(`UPDATE reviews SET ${updates.join(', ')} WHERE id = ? AND user_id = ?`, values);
  return findById(id);
}

async function deleteById(id, userId) {
  const [result] = await query(
    'DELETE FROM reviews WHERE id = ? AND user_id = ?',
    [id, userId]
  );
  return result.affectedRows > 0;
}

async function incrementHelpful(id) {
  await query('UPDATE reviews SET helpful_count = helpful_count + 1 WHERE id = ?', [id]);
}

module.exports = {
  getProductReviews, countProductReviews, getRatingDistribution,
  findUserReview, create, findById, updateById, deleteById, incrementHelpful,
};
