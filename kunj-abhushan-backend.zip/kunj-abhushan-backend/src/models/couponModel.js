'use strict';

const { query } = require('../config/db');

async function findByCode(code) {
  const [rows] = await query(
    `SELECT * FROM coupons
     WHERE code = ? AND is_active = 1
       AND (valid_from IS NULL OR valid_from <= NOW())
       AND (valid_until IS NULL OR valid_until >= NOW())`,
    [code.toUpperCase()]
  );
  return rows[0] || null;
}

async function validate(code, orderSubtotal) {
  const coupon = await findByCode(code);
  if (!coupon) return { valid: false, message: 'Invalid or expired coupon code.' };
  if (coupon.usage_limit && coupon.used_count >= coupon.usage_limit) {
    return { valid: false, message: 'This coupon has reached its usage limit.' };
  }
  if (orderSubtotal < coupon.min_order_value) {
    return { valid: false, message: `Minimum order value of ₹${coupon.min_order_value} required for this coupon.` };
  }

  let discount = coupon.type === 'percent'
    ? (orderSubtotal * coupon.value) / 100
    : coupon.value;

  if (coupon.max_discount) discount = Math.min(discount, coupon.max_discount);
  discount = parseFloat(discount.toFixed(2));

  return { valid: true, coupon, discount, message: `Coupon applied! You save ₹${discount}.` };
}

async function incrementUsage(code) {
  await query('UPDATE coupons SET used_count = used_count + 1 WHERE code = ?', [code.toUpperCase()]);
}

module.exports = { findByCode, validate, incrementUsage };
