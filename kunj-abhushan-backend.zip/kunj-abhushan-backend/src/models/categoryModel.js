'use strict';

const { query } = require('../config/db');

async function findAll(activeOnly = true) {
  const where = activeOnly ? 'WHERE is_active = 1' : '';
  const [rows] = await query(
    `SELECT id, name, slug, description, image_url, icon_emoji, parent_id, sort_order, is_active
     FROM categories ${where} ORDER BY sort_order ASC, name ASC`
  );
  return rows;
}

async function findById(id) {
  const [rows] = await query('SELECT * FROM categories WHERE id = ?', [id]);
  return rows[0] || null;
}

async function findBySlug(slug) {
  const [rows] = await query('SELECT * FROM categories WHERE slug = ?', [slug]);
  return rows[0] || null;
}

async function create(data) {
  const [result] = await query(
    'INSERT INTO categories (name, slug, description, image_url, icon_emoji, parent_id, sort_order, meta_title, meta_desc) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
    [data.name, data.slug, data.description || null, data.image_url || null, data.icon_emoji || '🙏', data.parent_id || null, data.sort_order || 0, data.meta_title || null, data.meta_desc || null]
  );
  return findById(result.insertId);
}

async function updateById(id, data) {
  const allowed = ['name', 'slug', 'description', 'image_url', 'icon_emoji', 'parent_id', 'sort_order', 'is_active', 'meta_title', 'meta_desc'];
  const updates = [];
  const values  = [];
  for (const [k, v] of Object.entries(data)) {
    if (allowed.includes(k)) { updates.push(`${k} = ?`); values.push(v); }
  }
  if (!updates.length) return findById(id);
  values.push(id);
  await query(`UPDATE categories SET ${updates.join(', ')} WHERE id = ?`, values);
  return findById(id);
}

async function slugExists(slug, excludeId = null) {
  const sql = excludeId
    ? 'SELECT id FROM categories WHERE slug = ? AND id != ?'
    : 'SELECT id FROM categories WHERE slug = ?';
  const params = excludeId ? [slug, excludeId] : [slug];
  const [rows] = await query(sql, params);
  return rows.length > 0;
}

module.exports = { findAll, findById, findBySlug, create, updateById, slugExists };
