'use strict';

const { query } = require('../config/db');

const SAFE_FIELDS = 'id, name, email, mobile, role, is_verified, is_active, avatar_url, last_login, created_at';

async function findById(id) {
  const [rows] = await query(`SELECT ${SAFE_FIELDS} FROM users WHERE id = ?`, [id]);
  return rows[0] || null;
}

async function findByMobile(mobile) {
  const [rows] = await query(`SELECT * FROM users WHERE mobile = ?`, [mobile]);
  return rows[0] || null;
}

async function findByEmail(email) {
  const [rows] = await query(`SELECT * FROM users WHERE email = ?`, [email]);
  return rows[0] || null;
}

async function create({ name, email, mobile, password_hash }) {
  const [result] = await query(
    'INSERT INTO users (name, email, mobile, password_hash, is_verified) VALUES (?, ?, ?, ?, 1)',
    [name, email || null, mobile, password_hash || null]
  );
  return findById(result.insertId);
}

async function updateById(id, fields) {
  const allowed = ['name', 'email', 'avatar_url', 'password_hash', 'last_login', 'refresh_token', 'is_verified', 'is_active'];
  const updates = [];
  const values  = [];
  for (const [k, v] of Object.entries(fields)) {
    if (allowed.includes(k)) { updates.push(`${k} = ?`); values.push(v); }
  }
  if (!updates.length) return findById(id);
  values.push(id);
  await query(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`, values);
  return findById(id);
}

async function deleteById(id) {
  await query('DELETE FROM users WHERE id = ?', [id]);
}

module.exports = { findById, findByMobile, findByEmail, create, updateById, deleteById };
