'use strict';

const { query } = require('../config/db');

async function getOrCreateCart(userId) {
  let [rows] = await query('SELECT id FROM cart WHERE user_id = ?', [userId]);
  if (rows.length) return rows[0].id;
  const [result] = await query('INSERT INTO cart (user_id) VALUES (?)', [userId]);
  return result.insertId;
}

async function getCartWithItems(userId) {
  const cartId = await getOrCreateCart(userId);

  const [items] = await query(
    `SELECT
       ci.id AS cart_item_id, ci.qty, ci.product_id,
       p.name, p.slug, p.price, p.original_price, p.stock_qty,
       p.sku, p.is_active,
       (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) AS image_url
     FROM cart_items ci
     JOIN products p ON p.id = ci.product_id
     WHERE ci.cart_id = ?
     ORDER BY ci.added_at DESC`,
    [cartId]
  );

  const subtotal = items.reduce((sum, i) => sum + (parseFloat(i.price) * i.qty), 0);
  const freeShippingThreshold = parseFloat(process.env.FREE_SHIPPING_THRESHOLD) || 499;
  const shippingCharge = subtotal > 0 && subtotal < freeShippingThreshold ? 60 : 0;
  const gstRate = parseFloat(process.env.GST_PERCENTAGE) || 0;
  const gstAmount = parseFloat(((subtotal * gstRate) / 100).toFixed(2));
  const total = parseFloat((subtotal + shippingCharge + gstAmount).toFixed(2));

  return {
    cart_id: cartId,
    items,
    item_count: items.reduce((s, i) => s + i.qty, 0),
    subtotal: parseFloat(subtotal.toFixed(2)),
    shipping_charge: shippingCharge,
    gst_amount: gstAmount,
    total,
    free_shipping_threshold: freeShippingThreshold,
    free_shipping_remaining: Math.max(0, freeShippingThreshold - subtotal),
  };
}

async function addItem(userId, productId, qty = 1) {
  const cartId = await getOrCreateCart(userId);
  await query(
    `INSERT INTO cart_items (cart_id, product_id, qty) VALUES (?, ?, ?)
     ON DUPLICATE KEY UPDATE qty = qty + VALUES(qty)`,
    [cartId, productId, qty]
  );
  return getCartWithItems(userId);
}

async function updateItemQty(userId, productId, qty) {
  const cartId = await getOrCreateCart(userId);
  if (qty <= 0) {
    await query('DELETE FROM cart_items WHERE cart_id = ? AND product_id = ?', [cartId, productId]);
  } else {
    await query('UPDATE cart_items SET qty = ? WHERE cart_id = ? AND product_id = ?', [qty, cartId, productId]);
  }
  return getCartWithItems(userId);
}

async function removeItem(userId, productId) {
  const cartId = await getOrCreateCart(userId);
  await query('DELETE FROM cart_items WHERE cart_id = ? AND product_id = ?', [cartId, productId]);
  return getCartWithItems(userId);
}

async function clearCart(userId) {
  const [rows] = await query('SELECT id FROM cart WHERE user_id = ?', [userId]);
  if (!rows.length) return;
  await query('DELETE FROM cart_items WHERE cart_id = ?', [rows[0].id]);
}

module.exports = { getOrCreateCart, getCartWithItems, addItem, updateItemQty, removeItem, clearCart };
