'use strict';

const { query } = require('../config/db');

async function findById(id, userId = null) {
  const where = userId ? 'WHERE o.id = ? AND o.user_id = ?' : 'WHERE o.id = ?';
  const params = userId ? [id, userId] : [id];
  const [rows] = await query(
    `SELECT o.*, u.name AS user_name, u.mobile AS user_mobile, u.email AS user_email
     FROM orders o JOIN users u ON u.id = o.user_id ${where}`,
    params
  );
  if (!rows.length) return null;
  const order = rows[0];
  order.items = await getOrderItems(order.id);
  order.payment = await getPayment(order.id);
  return order;
}

async function findByOrderNumber(orderNumber) {
  const [rows] = await query('SELECT * FROM orders WHERE order_number = ?', [orderNumber]);
  if (!rows.length) return null;
  return findById(rows[0].id);
}

async function getOrderItems(orderId) {
  const [rows] = await query(
    'SELECT * FROM order_items WHERE order_id = ? ORDER BY id ASC',
    [orderId]
  );
  return rows;
}

async function getPayment(orderId) {
  const [rows] = await query(
    'SELECT * FROM payments WHERE order_id = ? ORDER BY created_at DESC LIMIT 1',
    [orderId]
  );
  return rows[0] || null;
}

async function getUserOrders(userId, limit = 20, offset = 0) {
  const [rows] = await query(
    `SELECT o.id, o.order_number, o.status, o.payment_status, o.total_amount,
            o.created_at, o.ship_city, o.ship_state,
            COUNT(oi.id) AS item_count
     FROM orders o
     LEFT JOIN order_items oi ON oi.order_id = o.id
     WHERE o.user_id = ?
     GROUP BY o.id
     ORDER BY o.created_at DESC
     LIMIT ? OFFSET ?`,
    [userId, limit, offset]
  );
  return rows;
}

async function countUserOrders(userId) {
  const [rows] = await query('SELECT COUNT(*) AS total FROM orders WHERE user_id = ?', [userId]);
  return rows[0].total;
}

async function create(conn, orderData, items) {
  const [result] = await conn.execute(
    `INSERT INTO orders (
       order_number, user_id, status, payment_status, payment_method,
       subtotal, discount_amount, coupon_code, shipping_charge, gst_amount, total_amount,
       ship_name, ship_mobile, ship_line1, ship_line2, ship_city, ship_state, ship_pincode, ship_country, notes
     ) VALUES (?, ?, 'pending', 'unpaid', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      orderData.order_number, orderData.user_id, orderData.payment_method,
      orderData.subtotal, orderData.discount_amount || 0, orderData.coupon_code || null,
      orderData.shipping_charge, orderData.gst_amount, orderData.total_amount,
      orderData.ship_name, orderData.ship_mobile, orderData.ship_line1, orderData.ship_line2 || null,
      orderData.ship_city, orderData.ship_state, orderData.ship_pincode, orderData.ship_country || 'India',
      orderData.notes || null,
    ]
  );
  const orderId = result.insertId;

  for (const item of items) {
    await conn.execute(
      `INSERT INTO order_items (order_id, product_id, product_name, product_sku, product_image, qty, unit_price, total_price)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [orderId, item.product_id, item.name, item.sku || null, item.image_url || null, item.qty, item.price, item.price * item.qty]
    );
  }
  return orderId;
}

async function updateStatus(orderId, status, conn = null) {
  const db = conn || { execute: (sql, p) => query(sql, p) };
  await db.execute('UPDATE orders SET status = ? WHERE id = ?', [status, orderId]);
}

async function updatePaymentStatus(orderId, paymentStatus, conn = null) {
  const db = conn || { execute: (sql, p) => query(sql, p) };
  await db.execute('UPDATE orders SET payment_status = ? WHERE id = ?', [paymentStatus, orderId]);
}

module.exports = {
  findById, findByOrderNumber, getOrderItems, getPayment,
  getUserOrders, countUserOrders, create, updateStatus, updatePaymentStatus,
};
