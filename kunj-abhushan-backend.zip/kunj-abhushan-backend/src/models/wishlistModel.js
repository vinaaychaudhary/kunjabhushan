'use strict';

const { query } = require('../config/db');

async function getWishlist(userId) {
  const [rows] = await query(
    `SELECT
       w.id AS wishlist_id, w.created_at AS added_at,
       p.id AS product_id, p.name, p.slug, p.price, p.original_price,
       p.avg_rating, p.review_count, p.stock_qty, p.is_active,
       c.name AS category_name, c.slug AS category_slug,
       (SELECT image_url FROM product_images WHERE product_id = p.id AND is_primary = 1 LIMIT 1) AS image_url
     FROM wishlist w
     JOIN products p ON p.id = w.product_id
     JOIN categories c ON c.id = p.category_id
     WHERE w.user_id = ?
     ORDER BY w.created_at DESC`,
    [userId]
  );
  return rows;
}

async function addItem(userId, productId) {
  await query(
    'INSERT IGNORE INTO wishlist (user_id, product_id) VALUES (?, ?)',
    [userId, productId]
  );
}

async function removeItem(userId, productId) {
  const [result] = await query(
    'DELETE FROM wishlist WHERE user_id = ? AND product_id = ?',
    [userId, productId]
  );
  return result.affectedRows > 0;
}

async function isInWishlist(userId, productId) {
  const [rows] = await query(
    'SELECT id FROM wishlist WHERE user_id = ? AND product_id = ?',
    [userId, productId]
  );
  return rows.length > 0;
}

async function clearWishlist(userId) {
  await query('DELETE FROM wishlist WHERE user_id = ?', [userId]);
}

module.exports = { getWishlist, addItem, removeItem, isInWishlist, clearWishlist };
