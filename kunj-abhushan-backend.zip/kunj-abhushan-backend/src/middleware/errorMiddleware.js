'use strict';

/**
 * 404 handler — attach after all routes
 */
function notFound(req, res, next) {
  const err = new Error(`Route not found: ${req.originalUrl}`);
  err.statusCode = 404;
  next(err);
}

/**
 * Global error handler — attach last in server.js
 */
function errorHandler(err, req, res, next) {
  let statusCode = err.statusCode || err.status || 500;
  let message = err.message || 'Internal Server Error';

  // MySQL duplicate entry
  if (err.code === 'ER_DUP_ENTRY') {
    statusCode = 409;
    if (err.message.includes('mobile')) message = 'Mobile number already registered.';
    else if (err.message.includes('email')) message = 'Email address already registered.';
    else if (err.message.includes('slug')) message = 'A record with this name already exists.';
    else message = 'Duplicate entry. Record already exists.';
  }

  // MySQL foreign key violation
  if (err.code === 'ER_NO_REFERENCED_ROW_2') {
    statusCode = 400;
    message = 'Referenced record does not exist.';
  }

  // JWT errors
  if (err.name === 'JsonWebTokenError') { statusCode = 401; message = 'Invalid token.'; }
  if (err.name === 'TokenExpiredError') { statusCode = 401; message = 'Token expired. Please log in again.'; }

  const response = {
    success: false,
    message,
    ...(process.env.NODE_ENV !== 'production' && { stack: err.stack }),
  };

  if (process.env.NODE_ENV !== 'production') {
    console.error(`[ERROR] ${statusCode} — ${message}`);
  }

  res.status(statusCode).json(response);
}

module.exports = { notFound, errorHandler };
