'use strict';

const { validationResult } = require('express-validator');

/**
 * Reads express-validator results and short-circuits with 422 if invalid.
 */
function validate(req, res, next) {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    const messages = errors.array().map(e => e.msg);
    return res.status(422).json({
      success: false,
      message: messages[0],
      errors: messages,
    });
  }
  next();
}

module.exports = { validate };
