'use strict';

const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');

const MAX_SIZE = parseInt(process.env.UPLOAD_MAX_SIZE) || 5 * 1024 * 1024; // 5 MB
const ALLOWED_TYPES = /jpeg|jpg|png|webp|gif/;

function makeStorage(subfolder) {
  const dest = path.join(__dirname, '..', 'uploads', subfolder);
  if (!fs.existsSync(dest)) fs.mkdirSync(dest, { recursive: true });

  return multer.diskStorage({
    destination: (_req, _file, cb) => cb(null, dest),
    filename: (_req, file, cb) => {
      const ext = path.extname(file.originalname).toLowerCase();
      cb(null, `${uuidv4()}${ext}`);
    },
  });
}

function fileFilter(_req, file, cb) {
  const extOk  = ALLOWED_TYPES.test(path.extname(file.originalname).toLowerCase());
  const mimeOk = ALLOWED_TYPES.test(file.mimetype);
  if (extOk && mimeOk) return cb(null, true);
  cb(new Error('Only image files (jpg, png, webp, gif) are allowed.'));
}

/** Upload a single product image */
const uploadProductImage = multer({
  storage: makeStorage('products'),
  fileFilter,
  limits: { fileSize: MAX_SIZE },
}).single('image');

/** Upload up to 5 product images */
const uploadProductImages = multer({
  storage: makeStorage('products'),
  fileFilter,
  limits: { fileSize: MAX_SIZE },
}).array('images', 5);

/** Upload a single category image */
const uploadCategoryImage = multer({
  storage: makeStorage('categories'),
  fileFilter,
  limits: { fileSize: MAX_SIZE },
}).single('image');

/** Upload user avatar */
const uploadAvatar = multer({
  storage: makeStorage('avatars'),
  fileFilter,
  limits: { fileSize: 2 * 1024 * 1024 }, // 2 MB for avatars
}).single('avatar');

/**
 * Wraps a multer middleware to convert its callback errors into Express errors.
 */
function handleUpload(multerMiddleware) {
  return (req, res, next) => {
    multerMiddleware(req, res, (err) => {
      if (!err) return next();
      if (err instanceof multer.MulterError) {
        if (err.code === 'LIMIT_FILE_SIZE') {
          return res.status(400).json({ success: false, message: 'File too large. Maximum size is 5MB.' });
        }
        return res.status(400).json({ success: false, message: err.message });
      }
      return res.status(400).json({ success: false, message: err.message });
    });
  };
}

module.exports = {
  uploadProductImage:  handleUpload(uploadProductImage),
  uploadProductImages: handleUpload(uploadProductImages),
  uploadCategoryImage: handleUpload(uploadCategoryImage),
  uploadAvatar:        handleUpload(uploadAvatar),
};
