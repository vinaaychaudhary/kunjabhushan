'use strict';

const jwt = require('jsonwebtoken');
const { query } = require('../config/db');
const { sendError } = require('../utils/responseHelper');

/**
 * Verify JWT — attaches req.user on success.
 */
async function protect(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return sendError(res, 401, 'No token provided. Please log in.');
    }

    const token = authHeader.split(' ')[1];
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      if (err.name === 'TokenExpiredError') return sendError(res, 401, 'Session expired. Please log in again.');
      return sendError(res, 401, 'Invalid token. Please log in.');
    }

    const [rows] = await query(
      'SELECT id, name, email, mobile, role, is_active, avatar_url FROM users WHERE id = ?',
      [decoded.id]
    );

    if (!rows.length) return sendError(res, 401, 'User no longer exists.');
    if (!rows[0].is_active) return sendError(res, 403, 'Your account has been deactivated.');

    req.user = rows[0];
    next();
  } catch (err) {
    next(err);
  }
}

/**
 * Restrict to admin role only. Must be used after protect().
 */
function adminOnly(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return sendError(res, 403, 'Access denied. Admins only.');
  }
  next();
}

/**
 * Optional auth — attaches req.user if token present, but never blocks.
 */
async function optionalAuth(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) return next();

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const [rows] = await query(
      'SELECT id, name, email, mobile, role, is_active, avatar_url FROM users WHERE id = ? AND is_active = 1',
      [decoded.id]
    );
    if (rows.length) req.user = rows[0];
  } catch (_) {
    // token invalid or expired — silently ignore for optional auth
  }
  next();
}

module.exports = { protect, adminOnly, optionalAuth };
