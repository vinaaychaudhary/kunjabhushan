'use strict';

/**
 * Convert any string into a URL-safe slug.
 */
function slugify(text) {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/[\s_]+/g, '-')
    .replace(/[^\w-]+/g, '')
    .replace(/--+/g, '-')
    .replace(/^-+|-+$/g, '');
}

/**
 * Generate a unique slug by appending a timestamp if necessary.
 * @param {string} base - base text
 * @param {Function} exists - async fn(slug) => bool
 */
async function uniqueSlug(base, exists) {
  let slug = slugify(base);
  let candidate = slug;
  let i = 1;
  while (await exists(candidate)) {
    candidate = `${slug}-${i++}`;
  }
  return candidate;
}

/**
 * Generate a unique order number.
 */
function generateOrderNumber() {
  const ts  = Date.now().toString(36).toUpperCase();
  const rand = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `KA-${ts}-${rand}`;
}

module.exports = { slugify, uniqueSlug, generateOrderNumber };
