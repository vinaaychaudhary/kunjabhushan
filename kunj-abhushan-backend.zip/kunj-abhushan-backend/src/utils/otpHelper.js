'use strict';

const crypto = require('crypto');
const { query } = require('../config/db');

/**
 * Generate a cryptographically-random 6-digit OTP.
 */
function generateOTP() {
  return String(crypto.randomInt(100000, 999999));
}

/**
 * Save OTP to database, invalidating any previous OTPs for same mobile+purpose.
 */
async function saveOTP(mobile, otp, purpose = 'login') {
  const expiryMinutes = parseInt(process.env.OTP_EXPIRY_MINUTES) || 10;

  // Invalidate old OTPs for this mobile + purpose
  await query(
    'UPDATE otp_codes SET is_used = 1 WHERE mobile = ? AND purpose = ? AND is_used = 0',
    [mobile, purpose]
  );

  // Insert new OTP
  await query(
    `INSERT INTO otp_codes (mobile, otp, purpose, expires_at)
     VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL ? MINUTE))`,
    [mobile, otp, purpose, expiryMinutes]
  );
}

/**
 * Verify an OTP. Returns { valid: bool, message: string }.
 * Marks OTP as used on success.
 */
async function verifyOTP(mobile, otp, purpose = 'login') {
  const [rows] = await query(
    `SELECT id, is_used, attempts, expires_at
     FROM otp_codes
     WHERE mobile = ? AND otp = ? AND purpose = ?
     ORDER BY created_at DESC LIMIT 1`,
    [mobile, otp, purpose]
  );

  if (!rows.length) return { valid: false, message: 'Invalid OTP.' };

  const record = rows[0];

  if (record.is_used) return { valid: false, message: 'OTP already used.' };
  if (new Date(record.expires_at) < new Date()) return { valid: false, message: 'OTP expired. Please request a new one.' };
  if (record.attempts >= 5) return { valid: false, message: 'Too many failed attempts. Please request a new OTP.' };

  // Mark as used
  await query('UPDATE otp_codes SET is_used = 1 WHERE id = ?', [record.id]);

  return { valid: true, message: 'OTP verified.' };
}

/**
 * Increment the attempt counter for the latest OTP of a mobile+purpose pair.
 */
async function incrementOTPAttempts(mobile, purpose = 'login') {
  await query(
    `UPDATE otp_codes SET attempts = attempts + 1
     WHERE mobile = ? AND purpose = ? AND is_used = 0
     ORDER BY created_at DESC LIMIT 1`,
    [mobile, purpose]
  );
}

module.exports = { generateOTP, saveOTP, verifyOTP, incrementOTPAttempts };
