'use strict';

const jwt = require('jsonwebtoken');

/**
 * Generate a short-lived access token.
 */
function generateAccessToken(user) {
  return jwt.sign(
    { id: user.id, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

/**
 * Generate a long-lived refresh token.
 */
function generateRefreshToken(user) {
  return jwt.sign(
    { id: user.id },
    process.env.JWT_REFRESH_SECRET,
    { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '30d' }
  );
}

/**
 * Verify a refresh token and return its payload, or null.
 */
function verifyRefreshToken(token) {
  try {
    return jwt.verify(token, process.env.JWT_REFRESH_SECRET);
  } catch {
    return null;
  }
}

/**
 * Return both tokens as a convenience object.
 */
function generateTokenPair(user) {
  return {
    accessToken:  generateAccessToken(user),
    refreshToken: generateRefreshToken(user),
  };
}

module.exports = { generateAccessToken, generateRefreshToken, verifyRefreshToken, generateTokenPair };
