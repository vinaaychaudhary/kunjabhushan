'use strict';

const mysql = require('mysql2/promise');

const poolConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT) || 3306,
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'kunj_abhushan',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  timezone: '+05:30',
  charset: 'utf8mb4',
  namedPlaceholders: true,
  // Reconnect on disconnect
  enableKeepAlive: true,
  keepAliveInitialDelay: 0,
};

const pool = mysql.createPool(poolConfig);

/**
 * Test the database connection on startup.
 */
async function testConnection() {
  try {
    const conn = await pool.getConnection();
    console.log('✅ MySQL connected:', `${poolConfig.host}:${poolConfig.port}/${poolConfig.database}`);
    conn.release();
  } catch (error) {
    console.error('❌ MySQL connection failed:', error.message);
    throw error;
  }
}

/**
 * Execute a query with optional parameters.
 * @param {string} sql
 * @param {Array|Object} params
 * @returns {Promise<[RowDataPacket[], FieldPacket[]]>}
 */
async function query(sql, params = []) {
  try {
    const [rows, fields] = await pool.execute(sql, params);
    return [rows, fields];
  } catch (error) {
    console.error('DB Query Error:', error.message, '\nSQL:', sql);
    throw error;
  }
}

/**
 * Begin a transaction and return the connection.
 * Always call conn.release() in finally block.
 */
async function beginTransaction() {
  const conn = await pool.getConnection();
  await conn.beginTransaction();
  return conn;
}

module.exports = { pool, query, testConnection, beginTransaction };
