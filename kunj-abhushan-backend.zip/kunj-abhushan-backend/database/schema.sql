-- ============================================================
-- KUNJ ABHUSHAN — MySQL Database Schema
-- Run: mysql -u root -p < database/schema.sql
-- ============================================================

CREATE DATABASE IF NOT EXISTS kunj_abhushan
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE kunj_abhushan;

-- ── users ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(191) UNIQUE,
  mobile        VARCHAR(15)  NOT NULL UNIQUE,
  password_hash VARCHAR(255),
  avatar_url    VARCHAR(500),
  role          ENUM('customer','admin') NOT NULL DEFAULT 'customer',
  is_verified   TINYINT(1) NOT NULL DEFAULT 0,
  is_active     TINYINT(1) NOT NULL DEFAULT 1,
  refresh_token TEXT,
  last_login    DATETIME,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_mobile (mobile),
  INDEX idx_email  (email),
  INDEX idx_role   (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── user_addresses ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS user_addresses (
  id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id      INT UNSIGNED NOT NULL,
  label        VARCHAR(50) NOT NULL DEFAULT 'Home',
  full_name    VARCHAR(100) NOT NULL,
  mobile       VARCHAR(15)  NOT NULL,
  line1        VARCHAR(200) NOT NULL,
  line2        VARCHAR(200),
  city         VARCHAR(100) NOT NULL,
  state        VARCHAR(100) NOT NULL,
  pincode      VARCHAR(10)  NOT NULL,
  country      VARCHAR(50)  NOT NULL DEFAULT 'India',
  is_default   TINYINT(1) NOT NULL DEFAULT 0,
  created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── otp_codes ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS otp_codes (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  mobile      VARCHAR(15)  NOT NULL,
  otp         VARCHAR(6)   NOT NULL,
  purpose     ENUM('login','register','forgot_password','verify') NOT NULL DEFAULT 'login',
  is_used     TINYINT(1) NOT NULL DEFAULT 0,
  attempts    TINYINT    NOT NULL DEFAULT 0,
  expires_at  DATETIME NOT NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_mobile_purpose (mobile, purpose),
  INDEX idx_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── categories ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS categories (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  slug        VARCHAR(120) NOT NULL UNIQUE,
  description TEXT,
  image_url   VARCHAR(500),
  icon_emoji  VARCHAR(10)  DEFAULT '🙏',
  parent_id   INT UNSIGNED,
  sort_order  SMALLINT NOT NULL DEFAULT 0,
  is_active   TINYINT(1) NOT NULL DEFAULT 1,
  meta_title  VARCHAR(200),
  meta_desc   VARCHAR(500),
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (parent_id) REFERENCES categories(id) ON DELETE SET NULL,
  INDEX idx_slug     (slug),
  INDEX idx_active   (is_active),
  INDEX idx_parent   (parent_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── products ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS products (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  sku             VARCHAR(50) UNIQUE,
  name            VARCHAR(200) NOT NULL,
  slug            VARCHAR(220) NOT NULL UNIQUE,
  description     TEXT,
  short_desc      VARCHAR(500),
  category_id     INT UNSIGNED NOT NULL,
  price           DECIMAL(10,2) NOT NULL,
  original_price  DECIMAL(10,2),
  stock_qty       INT NOT NULL DEFAULT 0,
  low_stock_alert INT NOT NULL DEFAULT 5,
  weight_grams    INT,
  is_active       TINYINT(1) NOT NULL DEFAULT 1,
  is_featured     TINYINT(1) NOT NULL DEFAULT 0,
  is_bestseller   TINYINT(1) NOT NULL DEFAULT 0,
  is_new_arrival  TINYINT(1) NOT NULL DEFAULT 0,
  badge_text      VARCHAR(30),
  badge_color     VARCHAR(20),
  meta_title      VARCHAR(200),
  meta_desc       VARCHAR(500),
  avg_rating      DECIMAL(3,2) NOT NULL DEFAULT 0.00,
  review_count    INT UNSIGNED NOT NULL DEFAULT 0,
  sold_count      INT UNSIGNED NOT NULL DEFAULT 0,
  sort_order      SMALLINT NOT NULL DEFAULT 0,
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE RESTRICT,
  INDEX idx_slug        (slug),
  INDEX idx_category    (category_id),
  INDEX idx_active      (is_active),
  INDEX idx_featured    (is_featured),
  INDEX idx_bestseller  (is_bestseller),
  INDEX idx_new_arrival (is_new_arrival),
  INDEX idx_price       (price),
  FULLTEXT idx_ft_search (name, description, short_desc)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── product_images ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS product_images (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_id  INT UNSIGNED NOT NULL,
  image_url   VARCHAR(500) NOT NULL,
  alt_text    VARCHAR(200),
  is_primary  TINYINT(1) NOT NULL DEFAULT 0,
  sort_order  SMALLINT NOT NULL DEFAULT 0,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_product  (product_id),
  INDEX idx_primary  (product_id, is_primary)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── wishlist ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS wishlist (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL,
  product_id  INT UNSIGNED NOT NULL,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_user_product (user_id, product_id),
  FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_user_id (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── cart ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cart (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  user_id     INT UNSIGNED NOT NULL UNIQUE,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── cart_items ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS cart_items (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cart_id     INT UNSIGNED NOT NULL,
  product_id  INT UNSIGNED NOT NULL,
  qty         SMALLINT UNSIGNED NOT NULL DEFAULT 1,
  added_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_cart_product (cart_id, product_id),
  FOREIGN KEY (cart_id)    REFERENCES cart(id)     ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  INDEX idx_cart_id (cart_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── coupons ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS coupons (
  id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  code            VARCHAR(30) NOT NULL UNIQUE,
  description     VARCHAR(200),
  type            ENUM('percent','flat') NOT NULL DEFAULT 'percent',
  value           DECIMAL(10,2) NOT NULL,
  min_order_value DECIMAL(10,2) NOT NULL DEFAULT 0,
  max_discount    DECIMAL(10,2),
  usage_limit     INT,
  used_count      INT NOT NULL DEFAULT 0,
  is_active       TINYINT(1) NOT NULL DEFAULT 1,
  valid_from      DATETIME,
  valid_until     DATETIME,
  created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_code   (code),
  INDEX idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── orders ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS orders (
  id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_number     VARCHAR(30) NOT NULL UNIQUE,
  user_id          INT UNSIGNED NOT NULL,
  status           ENUM('pending','confirmed','processing','shipped','delivered','cancelled','refunded')
                   NOT NULL DEFAULT 'pending',
  payment_status   ENUM('unpaid','paid','failed','refunded') NOT NULL DEFAULT 'unpaid',
  payment_method   ENUM('razorpay','cod','upi','card','netbanking') NOT NULL DEFAULT 'razorpay',
  subtotal         DECIMAL(10,2) NOT NULL,
  discount_amount  DECIMAL(10,2) NOT NULL DEFAULT 0,
  coupon_code      VARCHAR(30),
  shipping_charge  DECIMAL(10,2) NOT NULL DEFAULT 0,
  gst_amount       DECIMAL(10,2) NOT NULL DEFAULT 0,
  total_amount     DECIMAL(10,2) NOT NULL,
  -- Shipping address snapshot (denormalized for order history)
  ship_name        VARCHAR(100) NOT NULL,
  ship_mobile      VARCHAR(15)  NOT NULL,
  ship_line1       VARCHAR(200) NOT NULL,
  ship_line2       VARCHAR(200),
  ship_city        VARCHAR(100) NOT NULL,
  ship_state       VARCHAR(100) NOT NULL,
  ship_pincode     VARCHAR(10)  NOT NULL,
  ship_country     VARCHAR(50)  NOT NULL DEFAULT 'India',
  -- Tracking
  tracking_number  VARCHAR(100),
  courier_name     VARCHAR(100),
  notes            TEXT,
  cancelled_reason VARCHAR(300),
  created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
  INDEX idx_user_id      (user_id),
  INDEX idx_order_number (order_number),
  INDEX idx_status       (status),
  INDEX idx_payment_status (payment_status),
  INDEX idx_created_at   (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── order_items ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS order_items (
  id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id      INT UNSIGNED NOT NULL,
  product_id    INT UNSIGNED NOT NULL,
  product_name  VARCHAR(200) NOT NULL,
  product_sku   VARCHAR(50),
  product_image VARCHAR(500),
  qty           SMALLINT UNSIGNED NOT NULL,
  unit_price    DECIMAL(10,2) NOT NULL,
  total_price   DECIMAL(10,2) NOT NULL,
  created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id)   REFERENCES orders(id)   ON DELETE CASCADE,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT,
  INDEX idx_order_id   (order_id),
  INDEX idx_product_id (product_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── payments ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS payments (
  id                     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  order_id               INT UNSIGNED NOT NULL,
  user_id                INT UNSIGNED NOT NULL,
  razorpay_order_id      VARCHAR(100),
  razorpay_payment_id    VARCHAR(100),
  razorpay_signature     VARCHAR(200),
  amount                 DECIMAL(10,2) NOT NULL,
  currency               VARCHAR(5) NOT NULL DEFAULT 'INR',
  status                 ENUM('created','attempted','paid','failed','refunded') NOT NULL DEFAULT 'created',
  method                 VARCHAR(50),
  bank                   VARCHAR(100),
  error_code             VARCHAR(100),
  error_description      TEXT,
  notes                  TEXT,
  captured_at            DATETIME,
  created_at             DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at             DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE RESTRICT,
  FOREIGN KEY (user_id)  REFERENCES users(id)  ON DELETE RESTRICT,
  INDEX idx_order_id          (order_id),
  INDEX idx_razorpay_order_id (razorpay_order_id),
  INDEX idx_razorpay_payment  (razorpay_payment_id),
  INDEX idx_status            (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── reviews ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS reviews (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  product_id  INT UNSIGNED NOT NULL,
  user_id     INT UNSIGNED NOT NULL,
  order_id    INT UNSIGNED,
  rating      TINYINT UNSIGNED NOT NULL CHECK (rating BETWEEN 1 AND 5),
  title       VARCHAR(150),
  body        TEXT NOT NULL,
  is_approved TINYINT(1) NOT NULL DEFAULT 1,
  is_verified TINYINT(1) NOT NULL DEFAULT 0,
  helpful_count INT UNSIGNED NOT NULL DEFAULT 0,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_user_product (user_id, product_id),
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id)    REFERENCES users(id)    ON DELETE CASCADE,
  FOREIGN KEY (order_id)   REFERENCES orders(id)   ON DELETE SET NULL,
  INDEX idx_product_id  (product_id),
  INDEX idx_user_id     (user_id),
  INDEX idx_rating      (rating),
  INDEX idx_approved    (is_approved)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── contact_messages ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS contact_messages (
  id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  email       VARCHAR(191) NOT NULL,
  mobile      VARCHAR(15),
  subject     VARCHAR(200),
  message     TEXT NOT NULL,
  status      ENUM('unread','read','replied','closed') NOT NULL DEFAULT 'unread',
  admin_notes TEXT,
  created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_status     (status),
  INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ── Triggers: keep avg_rating & review_count in sync ─────────
DELIMITER $$

CREATE TRIGGER trg_reviews_after_insert
AFTER INSERT ON reviews FOR EACH ROW
BEGIN
  UPDATE products SET
    avg_rating   = (SELECT IFNULL(AVG(rating), 0) FROM reviews WHERE product_id = NEW.product_id AND is_approved = 1),
    review_count = (SELECT COUNT(*)                FROM reviews WHERE product_id = NEW.product_id AND is_approved = 1)
  WHERE id = NEW.product_id;
END$$

CREATE TRIGGER trg_reviews_after_update
AFTER UPDATE ON reviews FOR EACH ROW
BEGIN
  UPDATE products SET
    avg_rating   = (SELECT IFNULL(AVG(rating), 0) FROM reviews WHERE product_id = NEW.product_id AND is_approved = 1),
    review_count = (SELECT COUNT(*)                FROM reviews WHERE product_id = NEW.product_id AND is_approved = 1)
  WHERE id = NEW.product_id;
END$$

CREATE TRIGGER trg_reviews_after_delete
AFTER DELETE ON reviews FOR EACH ROW
BEGIN
  UPDATE products SET
    avg_rating   = (SELECT IFNULL(AVG(rating), 0) FROM reviews WHERE product_id = OLD.product_id AND is_approved = 1),
    review_count = (SELECT COUNT(*)                FROM reviews WHERE product_id = OLD.product_id AND is_approved = 1)
  WHERE id = OLD.product_id;
END$$

DELIMITER ;
