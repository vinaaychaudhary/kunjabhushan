'use strict';

require('dotenv').config();
const bcrypt = require('bcryptjs');
const { query } = require('../src/config/db');

const categories = [
  { name: 'Tulsi Mala',         slug: 'tulsi-mala',         icon_emoji: '📿', description: 'Handcrafted Tulsi bead malas for daily worship and meditation.', sort_order: 1 },
  { name: 'Sacred Jewellery',   slug: 'sacred-jewellery',   icon_emoji: '💛', description: 'Divine jewellery crafted from sacred materials.', sort_order: 2 },
  { name: 'Chandan Tilak',      slug: 'chandan-tilak',      icon_emoji: '🌿', description: 'Pure sandalwood paste for auspicious tilak application.', sort_order: 3 },
  { name: 'Rose Freshener',     slug: 'rose-freshener',     icon_emoji: '🌹', description: 'Natural rose-based air fresheners for sacred spaces.', sort_order: 4 },
  { name: 'Chameli Freshener',  slug: 'chameli-freshener',  icon_emoji: '🌸', description: 'Jasmine fragrance fresheners for daily puja.', sort_order: 5 },
  { name: 'Gift Boxes',         slug: 'gift-boxes',         icon_emoji: '🎁', description: 'Premium devotional gift boxes for every occasion.', sort_order: 6 },
  { name: 'Combos',             slug: 'combos',             icon_emoji: '✨', description: 'Best value combo packs for complete devotional experience.', sort_order: 7 },
  { name: 'Fragrances',         slug: 'fragrances',         icon_emoji: '🪔', description: 'Divine fragrances to elevate your spiritual atmosphere.', sort_order: 8 },
];

const products = [
  {
    sku: 'TM-001', name: 'Premium Tulsi Mala – 108 Beads', slug: 'premium-tulsi-mala-108-beads',
    category_slug: 'tulsi-mala', price: 349, original_price: 499, stock_qty: 150,
    short_desc: 'Handcrafted 108-bead Tulsi Mala for japa meditation and daily puja.',
    description: 'Made from authentic Vrindavan Tulsi beads, this 108-bead mala is perfect for japa meditation. Each bead is individually hand-knotted with devotion. The sacred Tulsi wood carries divine energy and is believed to purify the wearer.',
    is_featured: 1, is_bestseller: 1, badge_text: 'BESTSELLER', badge_color: 'royal', weight_grams: 45,
  },
  {
    sku: 'TM-002', name: 'Tulsi Bracelet – Single Strand', slug: 'tulsi-bracelet-single-strand',
    category_slug: 'tulsi-mala', price: 149, original_price: 199, stock_qty: 200,
    short_desc: 'Simple and elegant single-strand Tulsi bracelet.',
    description: 'A beautiful single-strand Tulsi bracelet ideal for everyday wear. Made from genuine Tulsi wood beads with a smooth finish. Brings divine blessings and positive energy throughout the day.',
    is_bestseller: 1, badge_text: 'HOT', badge_color: 'sale',
  },
  {
    sku: 'SJ-001', name: 'Tulsi Earrings – Drop Style', slug: 'tulsi-earrings-drop-style',
    category_slug: 'sacred-jewellery', price: 249, original_price: 349, stock_qty: 80,
    short_desc: 'Delicate Tulsi bead drop earrings with gold-plated hooks.',
    description: 'Elegant drop-style earrings crafted from small Tulsi beads with gold-plated hooks. Perfect for daily wear and special occasions. A divine accessory that connects you to the divine.',
    is_new_arrival: 1, badge_text: 'NEW', badge_color: 'new',
  },
  {
    sku: 'CT-001', name: 'Pure Chandan Tilak – 12g', slug: 'pure-chandan-tilak-12g',
    category_slug: 'chandan-tilak', price: 149, original_price: 199, stock_qty: 300,
    short_desc: 'Authentic sandalwood paste tilak in premium packaging.',
    description: 'Made from genuine Mysore sandalwood, this tilak paste is used in daily puja and special occasions. The fragrance is natural and long-lasting. Comes in a hygienic sealed container of 12g.',
    is_featured: 1, is_bestseller: 1, badge_text: 'PURE', badge_color: 'royal',
  },
  {
    sku: 'RF-001', name: 'Gulab (Rose) Air Freshener – 100ml', slug: 'gulab-rose-air-freshener-100ml',
    category_slug: 'rose-freshener', price: 299, original_price: 399, stock_qty: 120,
    short_desc: 'Natural rose fragrance air freshener for home and puja room.',
    description: 'Fill your puja room and home with the divine fragrance of fresh roses. Made from natural rose extracts without harsh chemicals. Safe for use near idols and in enclosed spaces. 100ml long-lasting formula.',
    is_featured: 1, is_bestseller: 1, badge_text: 'BESTSELLER', badge_color: 'royal',
  },
  {
    sku: 'CF-001', name: 'Chameli (Jasmine) Air Freshener – 100ml', slug: 'chameli-jasmine-air-freshener-100ml',
    category_slug: 'chameli-freshener', price: 299, original_price: 399, stock_qty: 100,
    short_desc: 'Divine jasmine fragrance freshener for your sacred space.',
    description: 'Experience the divine fragrance of chameli (jasmine) in your home and puja room. The enchanting fragrance is known to create a serene and devotional atmosphere. Natural extracts, safe formula, 100ml.',
    is_new_arrival: 1, badge_text: 'NEW', badge_color: 'new',
  },
  {
    sku: 'GB-001', name: 'Divine Gift Box – Janmashtami Special', slug: 'divine-gift-box-janmashtami-special',
    category_slug: 'gift-boxes', price: 799, original_price: 1199, stock_qty: 50,
    short_desc: 'Premium devotional gift box with mala, tilak, and freshener.',
    description: 'The perfect devotional gift for Janmashtami and all auspicious occasions. Includes: 1 Premium Tulsi Mala, 1 Chandan Tilak, 1 Rose Freshener, 1 Chameli Freshener. All packed in a premium royal blue box with gold ribbon. Ideal for gifting to family and devotees.',
    is_featured: 1, badge_text: 'GIFT', badge_color: 'royal',
  },
  {
    sku: 'CB-001', name: 'Puja Combo – Complete Starter Pack', slug: 'puja-combo-complete-starter-pack',
    category_slug: 'combos', price: 599, original_price: 849, stock_qty: 75,
    short_desc: 'Everything you need for daily puja in one combo.',
    description: 'The complete daily puja combo for every devotee. Includes: 1 Tulsi Mala (108 beads), 1 Tulsi Bracelet, 1 Chandan Tilak (12g), 1 Rose Freshener (100ml). Save ₹250 compared to buying individually. Perfect for beginners and seasoned devotees alike.',
    is_featured: 1, is_bestseller: 1, badge_text: 'SAVE 30%', badge_color: 'sale',
  },
  {
    sku: 'TM-003', name: 'Tulsi Mala – Double Strand 54 Beads', slug: 'tulsi-mala-double-strand-54-beads',
    category_slug: 'tulsi-mala', price: 279, original_price: 349, stock_qty: 90,
    short_desc: 'Beautiful double-strand 54-bead Tulsi Mala.',
    description: 'A unique double-strand mala made from 54 authentic Tulsi beads. Can be worn as a necklace or used for japa meditation. The double strand design is elegant and spiritually significant.',
    is_new_arrival: 1, badge_text: 'NEW', badge_color: 'new',
  },
  {
    sku: 'FR-001', name: 'Mogra Fragrance Spray – 100ml', slug: 'mogra-fragrance-spray-100ml',
    category_slug: 'fragrances', price: 349, original_price: 449, stock_qty: 60,
    short_desc: 'Refreshing mogra fragrance for home and puja room.',
    description: 'The divine fragrance of mogra (Arabian jasmine) brings peace and positivity to any space. Made from natural floral extracts. Long-lasting 100ml spray bottle. Ideal for puja rooms, bedrooms, and living areas.',
    is_new_arrival: 1,
  },
  {
    sku: 'SJ-002', name: 'Tulsi Pendant – Silver Plated', slug: 'tulsi-pendant-silver-plated',
    category_slug: 'sacred-jewellery', price: 399, original_price: 549, stock_qty: 45,
    short_desc: 'Silver-plated Tulsi pendant with chain.',
    description: 'A beautiful silver-plated pendant featuring a sacred Tulsi leaf design. Comes with an 18-inch silver chain. The pendant is believed to provide divine protection and blessings. Perfect for daily wear.',
    is_featured: 1, is_new_arrival: 1, badge_text: 'NEW', badge_color: 'new',
  },
  {
    sku: 'GB-002', name: 'Wedding Gift Box – Luxury Collection', slug: 'wedding-gift-box-luxury-collection',
    category_slug: 'gift-boxes', price: 1499, original_price: 1999, stock_qty: 25,
    short_desc: 'Premium luxury gift box perfect for weddings and special ceremonies.',
    description: 'The ultimate devotional gift for weddings and special ceremonies. Includes premium Tulsi Mala, Tulsi Bracelet pair, silver-plated pendant, Chandan Tilak, Rose Freshener, and Chameli Freshener. Beautifully presented in a handcrafted wooden box with silk lining.',
    badge_text: 'LUXURY', badge_color: 'royal',
  },
];

async function seed() {
  console.log('🌱 Seeding database...');

  try {
    // Seed admin user
    const adminHash = await bcrypt.hash('Admin@123', 12);
    await query(`
      INSERT IGNORE INTO users (name, email, mobile, password_hash, role, is_verified)
      VALUES ('Admin', 'admin@kunjabhushan.com', '9999999999', ?, 'admin', 1)
    `, [adminHash]);
    console.log('✅ Admin user seeded (mobile: 9999999999, password: Admin@123)');

    // Seed categories
    for (const cat of categories) {
      await query(`
        INSERT IGNORE INTO categories (name, slug, description, icon_emoji, sort_order, is_active)
        VALUES (?, ?, ?, ?, ?, 1)
      `, [cat.name, cat.slug, cat.description, cat.icon_emoji, cat.sort_order]);
    }
    console.log('✅ Categories seeded');

    // Get category slug → id map
    const [catRows] = await query('SELECT id, slug FROM categories');
    const catMap = {};
    catRows.forEach(r => { catMap[r.slug] = r.id; });

    // Seed products
    for (const p of products) {
      const catId = catMap[p.category_slug];
      if (!catId) { console.warn(`⚠️  Category not found: ${p.category_slug}`); continue; }

      const [existing] = await query('SELECT id FROM products WHERE sku = ?', [p.sku]);
      if (existing.length > 0) continue;

      const [result] = await query(`
        INSERT INTO products (
          sku, name, slug, description, short_desc, category_id,
          price, original_price, stock_qty, is_active, is_featured,
          is_bestseller, is_new_arrival, badge_text, badge_color, weight_grams
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?)
      `, [
        p.sku, p.name, p.slug, p.description, p.short_desc, catId,
        p.price, p.original_price || null, p.stock_qty,
        p.is_featured || 0, p.is_bestseller || 0, p.is_new_arrival || 0,
        p.badge_text || null, p.badge_color || null, p.weight_grams || null,
      ]);

      // Add placeholder image
      await query(`
        INSERT INTO product_images (product_id, image_url, alt_text, is_primary, sort_order)
        VALUES (?, ?, ?, 1, 0)
      `, [result.insertId, `/uploads/products/placeholder.webp`, p.name]);
    }
    console.log('✅ Products seeded');

    // Seed sample coupon
    await query(`
      INSERT IGNORE INTO coupons (code, description, type, value, min_order_value, max_discount, usage_limit, is_active, valid_until)
      VALUES
        ('KUNJ10', '10% off on all orders', 'percent', 10, 299, 100, 1000, 1, DATE_ADD(NOW(), INTERVAL 1 YEAR)),
        ('WELCOME50', 'Flat ₹50 off on first order', 'flat', 50, 199, 50, 500, 1, DATE_ADD(NOW(), INTERVAL 6 MONTH))
    `);
    console.log('✅ Coupons seeded (KUNJ10, WELCOME50)');

    console.log('\n🎉 Database seeding completed!');
    process.exit(0);
  } catch (err) {
    console.error('❌ Seeding failed:', err.message);
    process.exit(1);
  }
}

seed();
